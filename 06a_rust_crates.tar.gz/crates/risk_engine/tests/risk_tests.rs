// crates/risk_engine/tests/risk_tests.rs
#[cfg(test)]
mod tests {
    use jdl_core::{
        config::RiskConfig,
        types::MarketRegime,
    };
    use risk_engine::RiskEngine;
    use rust_decimal::Decimal;

    fn test_config() -> RiskConfig {
        RiskConfig {
            max_position_usd: Decimal::from(50_000u64),
            max_daily_loss_usd: Decimal::from(5_000u64),
            circuit_breaker_loss_pct: 0.10,
            max_gas_gwei: 50,
            min_oracle_health: 0.90,
            max_network_congestion: 0.80,
        }
    }

    #[tokio::test]
    async fn test_circuit_breaker_trip_and_reset() {
        let engine = RiskEngine::new(test_config());

        // Initially closed
        let signal = engine.current().await;
        assert!(!signal.circuit_breaker_open);

        // Trip
        engine.open_circuit_breaker().await;
        let signal = engine.current().await;
        assert!(signal.circuit_breaker_open);

        // Reset
        engine.close_circuit_breaker().await;
        let signal = engine.current().await;
        assert!(!signal.circuit_breaker_open);
    }

    #[tokio::test]
    async fn test_oracle_manipulation_detection() {
        let engine = RiskEngine::new(test_config());

        // Normal price — no manipulation
        let healthy = engine.update_price(3200.0, Some(3210.0)).await;
        assert!(healthy, "Small deviation (0.3%) should be healthy");

        // Manipulation: 10% deviation from Chainlink
        let manipulated = engine.update_price(3520.0, Some(3200.0)).await;
        assert!(!manipulated, "10% deviation should trigger manipulation alert");
    }

    #[tokio::test]
    async fn test_gas_congestion_scoring() {
        let engine = RiskEngine::new(test_config());

        engine.update_gas(10).await;
        let signal = engine.current().await;
        assert_eq!(signal.gas_price_gwei, 10);
        assert!((signal.network_congestion - 0.2).abs() < 0.01,
            "10/50 = 0.2 congestion");

        engine.update_gas(50).await;
        let signal = engine.current().await;
        assert!((signal.network_congestion - 1.0).abs() < 0.01,
            "50/50 = 1.0 (max) congestion");
    }

    #[tokio::test]
    async fn test_high_volatility_reduces_max_position() {
        let engine = RiskEngine::new(test_config());

        // Feed volatile price series
        let prices = vec![
            100.0, 115.0, 98.0, 120.0, 95.0, 118.0, 92.0, 125.0, 90.0, 130.0,
        ];
        for p in &prices {
            engine.update_price(*p, None).await;
        }

        let signal = engine.current().await;
        // High volatility → smaller max position
        println!("Regime: {:?}, max_pos: {}", signal.regime, signal.max_position_wei);

        // Max position in high volatility should be reduced
        if signal.regime == MarketRegime::HighVolatility {
            let max_pos_eth = signal.max_position_wei.as_u128() as f64 / 1e18;
            assert!(max_pos_eth < 5.0, "High vol should cap position below 5 ETH");
        }
    }
}
