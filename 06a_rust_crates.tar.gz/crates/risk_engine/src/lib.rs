// crates/risk_engine/src/lib.rs
//! Real-time risk assessment feeding into execution gating.
//! Detects: oracle manipulation, gas spike, network congestion, regime shifts.

use std::sync::Arc;
use std::collections::VecDeque;

use anyhow::Result;
use chrono::Utc;
use ethers::types::{Address, U256};
use jdl_core::{
    config::RiskConfig,
    types::{MarketRegime, RiskSignal},
};
use tokio::sync::RwLock;
use tracing::{info, warn};

const PRICE_HISTORY_LEN: usize = 20;
const ORACLE_DEVIATION_THRESHOLD: f64 = 0.05; // 5% max deviation between sources

#[derive(Debug, Clone)]
struct PriceObservation {
    price: f64,
    timestamp: chrono::DateTime<Utc>,
}

pub struct RiskEngine {
    config: RiskConfig,
    price_history: Arc<RwLock<VecDeque<PriceObservation>>>,
    current_signal: Arc<RwLock<RiskSignal>>,
}

impl RiskEngine {
    pub fn new(config: RiskConfig) -> Self {
        let initial_signal = RiskSignal {
            regime: MarketRegime::Ranging,
            gas_price_gwei: 0,
            network_congestion: 0.0,
            oracle_health: 1.0,
            circuit_breaker_open: false,
            max_position_wei: U256::from(10u64).pow(U256::from(18u64)), // 1 ETH default
            timestamp: Utc::now(),
        };

        Self {
            config,
            price_history: Arc::new(RwLock::new(VecDeque::with_capacity(PRICE_HISTORY_LEN))),
            current_signal: Arc::new(RwLock::new(initial_signal)),
        }
    }

    /// Get latest risk signal (non-blocking read)
    pub async fn current(&self) -> RiskSignal {
        self.current_signal.read().await.clone()
    }

    /// Update with new gas price and recompute signal
    pub async fn update_gas(&self, gas_gwei: u64) {
        let mut signal = self.current_signal.write().await;
        signal.gas_price_gwei = gas_gwei;
        signal.network_congestion = (gas_gwei as f64 / self.config.max_gas_gwei as f64).min(1.0);

        if gas_gwei > self.config.max_gas_gwei {
            warn!("Gas spike detected: {} gwei > max {} gwei", gas_gwei, self.config.max_gas_gwei);
        }
    }

    /// Update with new reference price and detect oracle manipulation
    pub async fn update_price(&self, price: f64, chainlink_price: Option<f64>) -> bool {
        let mut history = self.price_history.write().await;

        if history.len() >= PRICE_HISTORY_LEN {
            history.pop_front();
        }
        history.push_back(PriceObservation {
            price,
            timestamp: Utc::now(),
        });

        // Oracle deviation check
        let oracle_healthy = if let Some(cl_price) = chainlink_price {
            let deviation = ((price - cl_price) / cl_price).abs();
            if deviation > ORACLE_DEVIATION_THRESHOLD {
                warn!(
                    "Oracle manipulation detected: DEX price {:.4} vs Chainlink {:.4} = {:.2}% deviation",
                    price, cl_price, deviation * 100.0
                );
                false
            } else {
                true
            }
        } else {
            true
        };

        // Regime detection from price history
        let regime = self.detect_regime(&history);

        let mut signal = self.current_signal.write().await;
        signal.oracle_health = if oracle_healthy { 1.0 } else { 0.0 };
        signal.regime = regime;
        signal.timestamp = Utc::now();

        // Adjust max position based on regime
        signal.max_position_wei = self.compute_max_position(&signal.regime);

        oracle_healthy
    }

    /// Trip the circuit breaker (called by TxExecutor on loss limit breach)
    pub async fn open_circuit_breaker(&self) {
        let mut signal = self.current_signal.write().await;
        signal.circuit_breaker_open = true;
        warn!("Risk engine: circuit breaker OPENED");
    }

    pub async fn close_circuit_breaker(&self) {
        let mut signal = self.current_signal.write().await;
        signal.circuit_breaker_open = false;
        info!("Risk engine: circuit breaker CLOSED");
    }

    fn detect_regime(&self, history: &VecDeque<PriceObservation>) -> MarketRegime {
        if history.len() < 5 {
            return MarketRegime::Ranging;
        }

        let prices: Vec<f64> = history.iter().map(|o| o.price).collect();
        let n = prices.len() as f64;

        // Mean and std deviation
        let mean = prices.iter().sum::<f64>() / n;
        let variance = prices.iter().map(|p| (p - mean).powi(2)).sum::<f64>() / n;
        let std_dev = variance.sqrt();
        let cv = std_dev / mean; // coefficient of variation

        // Simple linear trend via slope
        let x_mean = (n - 1.0) / 2.0;
        let slope = prices.iter().enumerate().map(|(i, p)| {
            (i as f64 - x_mean) * (p - mean)
        }).sum::<f64>() / prices.iter().enumerate().map(|(i, _)| {
            (i as f64 - x_mean).powi(2)
        }).sum::<f64>();

        let trend_strength = (slope / mean).abs();

        match (cv, trend_strength) {
            (cv, _) if cv > 0.05 => MarketRegime::HighVolatility,
            (_, ts) if ts > 0.002 => MarketRegime::Trending,
            (cv, _) if cv < 0.005 => MarketRegime::LowVolatility,
            _ => MarketRegime::Ranging,
        }
    }

    fn compute_max_position(&self, regime: &MarketRegime) -> U256 {
        // Scale max position by regime risk
        let multiplier = match regime {
            MarketRegime::LowVolatility => 1.0,
            MarketRegime::Ranging => 0.8,
            MarketRegime::Trending => 0.6,
            MarketRegime::HighVolatility => 0.3,
            MarketRegime::Stressed => 0.1,
        };

        let max_usd = self.config.max_position_usd
            .to_string().parse::<f64>().unwrap_or(10_000.0);
        let max_eth = (max_usd * multiplier) / 3200.0;
        let max_wei = (max_eth * 1e18) as u128;
        U256::from(max_wei)
    }
}
