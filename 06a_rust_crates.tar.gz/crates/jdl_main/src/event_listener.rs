// crates/jdl_main/src/event_listener.rs
//! Subscribes to on-chain Sync events from DEX pools.
//! Feeds live reserve updates into PathFinder graph in real-time.

use std::sync::Arc;
use anyhow::Result;
use ethers::{
    abi::{Abi, Event, RawLog},
    contract::BaseContract,
    providers::{Provider, StreamExt, Ws},
    types::{Address, Filter, Log, H256, U256},
};
use path_finder::PathFinder;
use risk_engine::RiskEngine;
use tracing::{debug, info, warn, error};

// keccak256("Sync(uint112,uint112)") — UniswapV2 style
const SYNC_TOPIC: &str = "0x1c411e9a96e071241c2f21f7726b17ae89e3cab4c78be50e062b03a9fffbbad1";

// Known pool addresses to track (Arbitrum mainnet — top pairs)
// In production: load from DB or discovery mechanism
const BOOTSTRAP_POOLS: &[(&str, &str, &str, &str, &str, u32)] = &[
    // (address, dex, token0_addr, token0_sym, token1_addr... etc)
    // Populated at runtime from pool discovery or config
];

pub struct ChainEventListener {
    ws_url: String,
    path_finder: Arc<PathFinder>,
    risk_engine: Arc<RiskEngine>,
}

impl ChainEventListener {
    pub fn new(
        ws_url: String,
        path_finder: Arc<PathFinder>,
        risk_engine: Arc<RiskEngine>,
    ) -> Self {
        Self { ws_url, path_finder, risk_engine }
    }

    pub async fn run(&self) -> Result<()> {
        let provider = Provider::<Ws>::connect(&self.ws_url).await?;
        let provider = Arc::new(provider);

        info!("Chain event listener connected");

        // Subscribe to all Sync events
        let sync_topic: H256 = SYNC_TOPIC.parse()?;
        let filter = Filter::new().topic0(sync_topic);

        let mut stream = provider.subscribe_logs(&filter).await?;

        while let Some(log) = stream.next().await {
            if let Err(e) = self.handle_sync_log(&log).await {
                debug!("Sync log parse error: {}", e);
            }
        }

        warn!("Chain event stream ended");
        Ok(())
    }

    async fn handle_sync_log(&self, log: &Log) -> Result<()> {
        let pool_address = log.address;

        // Sync(uint112 reserve0, uint112 reserve1) — packed in data field
        if log.data.len() < 64 {
            return Ok(());
        }

        let reserve0 = U256::from_big_endian(&log.data[0..32]);
        let reserve1 = U256::from_big_endian(&log.data[32..64]);

        debug!(
            "Sync: pool={:?} r0={} r1={}",
            pool_address,
            reserve0,
            reserve1
        );

        // Update path finder graph
        self.path_finder
            .update_pool_reserves(pool_address, reserve0, reserve1)
            .await;

        Ok(())
    }
}
