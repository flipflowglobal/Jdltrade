// crates/jdl_main/src/db.rs
//! SQLite persistence layer for trade history, PnL tracking, and audit log.

use anyhow::Result;
use chrono::Utc;
use sqlx::{sqlite::SqlitePoolOptions, SqlitePool};
use tracing::info;
use jdl_core::types::{ArbPath, ExecutionResult};

pub struct TradeDb {
    pool: SqlitePool,
}

impl TradeDb {
    pub async fn new(db_path: &str) -> Result<Self> {
        // Create parent dirs if needed
        if let Some(parent) = std::path::Path::new(db_path).parent() {
            std::fs::create_dir_all(parent)?;
        }

        let url = format!("sqlite://{}?mode=rwc", db_path);
        let pool = SqlitePoolOptions::new()
            .max_connections(5)
            .connect(&url)
            .await?;

        let db = Self { pool };
        db.migrate().await?;
        Ok(db)
    }

    async fn migrate(&self) -> Result<()> {
        sqlx::query(
            r#"
            CREATE TABLE IF NOT EXISTS arb_executions (
                id              TEXT PRIMARY KEY,
                tx_hash         TEXT,
                success         INTEGER NOT NULL,
                hops            INTEGER NOT NULL,
                input_amount    TEXT NOT NULL,
                expected_profit TEXT NOT NULL,
                actual_profit   TEXT NOT NULL,
                gas_used        INTEGER NOT NULL,
                gas_price_gwei  INTEGER,
                error           TEXT,
                executed_at     TEXT NOT NULL,
                created_at      TEXT NOT NULL DEFAULT (datetime('now'))
            );

            CREATE TABLE IF NOT EXISTS pool_updates (
                pool_address    TEXT NOT NULL,
                reserve0        TEXT NOT NULL,
                reserve1        TEXT NOT NULL,
                updated_at      TEXT NOT NULL
            );

            CREATE INDEX IF NOT EXISTS idx_executions_success
                ON arb_executions(success, executed_at);

            CREATE INDEX IF NOT EXISTS idx_executions_date
                ON arb_executions(executed_at);
            "#
        )
        .execute(&self.pool)
        .await?;

        info!("Database schema initialized");
        Ok(())
    }

    pub async fn record_execution(&self, path: &ArbPath, result: &ExecutionResult) -> Result<()> {
        let tx_hash = result.tx_hash.map(|h| format!("{:?}", h));

        sqlx::query(
            r#"
            INSERT INTO arb_executions
                (id, tx_hash, success, hops, input_amount, expected_profit,
                 actual_profit, gas_used, error, executed_at)
            VALUES
                (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            "#
        )
        .bind(path.id.to_string())
        .bind(tx_hash)
        .bind(result.success as i64)
        .bind(path.hops.len() as i64)
        .bind(path.input_amount.to_string())
        .bind(path.expected_profit_wei.to_string())
        .bind(result.profit_wei.to_string())
        .bind(result.gas_used as i64)
        .bind(&result.error)
        .bind(result.executed_at.to_rfc3339())
        .execute(&self.pool)
        .await?;

        Ok(())
    }

    pub async fn daily_pnl(&self) -> Result<i128> {
        let today = Utc::now().date_naive().to_string();
        let row: (Option<String>,) = sqlx::query_as(
            "SELECT SUM(CAST(actual_profit AS INTEGER)) FROM arb_executions WHERE executed_at LIKE ?"
        )
        .bind(format!("{}%", today))
        .fetch_one(&self.pool)
        .await?;

        Ok(row.0.and_then(|s| s.parse().ok()).unwrap_or(0))
    }

    pub async fn execution_stats(&self) -> Result<(i64, i64, i64)> {
        // (total, success, failed)
        let row: (i64, i64) = sqlx::query_as(
            "SELECT COUNT(*), SUM(success) FROM arb_executions"
        )
        .fetch_one(&self.pool)
        .await?;

        let total = row.0;
        let success = row.1;
        Ok((total, success, total - success))
    }
}
