// crates/jdl_main/src/main.rs
//! JDL Rust Standalone Mode
//! Runs the full Rust engine independently (no Python required).
//! Use this for pure-Rust production deployment or benchmarking.

mod db;
mod event_listener;

use std::sync::Arc;
use std::time::Duration;

use anyhow::Result;
use ethers::{
    providers::{Http, Middleware, Provider, StreamExt, Ws},
    types::{Address, U256},
};
use jdl_core::{
    config::JdlConfig,
    metrics::serve_metrics,
    types::{RiskSignal, Token},
};
use mempool_scanner::{MempoolScanner, SwapSignal};
use path_finder::PathFinder;
use risk_engine::RiskEngine;
use tokio::sync::broadcast;
use tracing::{error, info, warn};
use tracing_subscriber::{fmt, EnvFilter};

use db::TradeDb;
use event_listener::ChainEventListener;

#[tokio::main]
async fn main() -> Result<()> {
    // ── Logging ───────────────────────────────────────────────
    let config = JdlConfig::from_env()?;

    tracing_subscriber::fmt()
        .with_env_filter(
            EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| EnvFilter::new(&config.monitoring.log_level))
        )
        .with_target(true)
        .compact()
        .init();

    info!("🦀 JDL Rust Engine v0.1.0 starting...");
    info!("Chain ID: {} | Dry Run: {}", config.network.chain_id, config.execution.dry_run);

    // ── Database ──────────────────────────────────────────────
    let db = Arc::new(TradeDb::new(&config.monitoring.sqlite_path).await?);
    info!("Database connected: {}", config.monitoring.sqlite_path);

    // ── Core Services ─────────────────────────────────────────
    let risk_engine = Arc::new(RiskEngine::new(config.risk.clone()));
    let path_finder = Arc::new(PathFinder::new(
        config.execution.max_hops,
        0, // min_profit_wei — filtered at execution stage
    ));

    // ── Transaction Executor ──────────────────────────────────
    let tx_executor = Arc::new(
        tx_executor::TxExecutor::new(config.clone()).await
            .map_err(|e| anyhow::anyhow!("Failed to init tx executor: {}", e))?
    );
    info!("Executor wallet: {:?}", tx_executor.address());

    // ── Metrics Server ────────────────────────────────────────
    let metrics_port = config.monitoring.metrics_port;
    tokio::spawn(async move {
        if let Err(e) = serve_metrics(metrics_port).await {
            error!("Metrics server error: {}", e);
        }
    });
    info!("Metrics: http://0.0.0.0:{}/metrics", config.monitoring.metrics_port);

    // ── Chain Event Listener (pool Sync events) ────────────────
    let listener = ChainEventListener::new(
        config.network.rpc_ws_url.clone(),
        path_finder.clone(),
        risk_engine.clone(),
    );
    tokio::spawn(async move {
        loop {
            if let Err(e) = listener.run().await {
                error!("Chain event listener error: {}", e);
            }
            tokio::time::sleep(Duration::from_secs(3)).await;
        }
    });

    // ── Mempool Scanner ───────────────────────────────────────
    let (scanner, mut swap_rx, _raw_rx) = MempoolScanner::new(
        config.network.rpc_ws_url.clone(),
        500.0, // min $500 USD to act on
    );

    tokio::spawn(async move {
        scanner.run().await.ok();
    });

    // ── WETH as default input token ───────────────────────────
    let weth = Token {
        address: "0x82aF49447D8a07e3bd95BD0d56f35241523fBab1"
            .parse::<Address>()?,
        symbol: "WETH".to_string(),
        decimals: 18,
    };
    let flash_amount = U256::from(100_000_000_000_000_000u128); // 0.1 ETH

    // ── Gas Price Poller ──────────────────────────────────────
    let http_provider = Provider::<Http>::try_from(&config.network.rpc_http_url)?;
    let http_provider = Arc::new(http_provider);
    let gas_oracle = Arc::new(tx_executor::GasOracle::new(config.risk.max_gas_gwei));
    let risk_engine_gas = risk_engine.clone();
    let gas_oracle_clone = gas_oracle.clone();
    let provider_gas = http_provider.clone();

    tokio::spawn(async move {
        loop {
            match gas_oracle_clone.get_gas_price(&provider_gas).await {
                Ok(gwei) => {
                    risk_engine_gas.update_gas(gwei).await;
                }
                Err(e) => warn!("Gas price fetch failed: {}", e),
            }
            tokio::time::sleep(Duration::from_secs(5)).await;
        }
    });

    // ── Daily Loss Reset (midnight UTC) ──────────────────────
    let tx_exec_reset = tx_executor.clone();
    let re_reset = risk_engine.clone();
    tokio::spawn(async move {
        loop {
            let now = chrono::Utc::now();
            let midnight = (now.date_naive() + chrono::Duration::days(1))
                .and_hms_opt(0, 0, 0)
                .unwrap()
                .and_utc();
            let until_midnight = (midnight - now).to_std().unwrap_or(Duration::from_secs(86400));
            tokio::time::sleep(until_midnight).await;
            tx_exec_reset.reset_daily_loss().await;
            re_reset.close_circuit_breaker().await;
            info!("Daily loss counter reset at midnight UTC");
        }
    });

    // ── Main Arbitrage Loop ───────────────────────────────────
    info!("🚀 Arbitrage engine active — listening for opportunities...");

    loop {
        // Triggered by mempool swap signals OR periodic scan
        let trigger = tokio::select! {
            // Mempool-triggered: large swap detected, scan immediately
            Ok(signal) = swap_rx.recv() => {
                info!(
                    "Mempool trigger: {}->{} ${:.0} impact={:.3}%",
                    signal.swap.token_in.symbol,
                    signal.swap.token_out.symbol,
                    signal.swap.amount_in.as_u128() as f64 / 1e18 * 3200.0,
                    signal.estimated_price_impact * 100.0
                );
                true
            }
            // Periodic scan every block (~250ms on Arbitrum)
            _ = tokio::time::sleep(Duration::from_millis(250)) => true,
        };

        if !trigger {
            continue;
        }

        // Get current risk state
        let risk = risk_engine.current().await;

        if risk.circuit_breaker_open {
            warn!("Circuit breaker open — skipping scan");
            continue;
        }

        if risk.gas_price_gwei > config.risk.max_gas_gwei {
            continue; // Silent skip on gas spike
        }

        // Run path finding
        match path_finder
            .find_opportunities(&weth, flash_amount, risk.gas_price_gwei, &risk)
            .await
        {
            Ok(paths) if !paths.is_empty() => {
                let best = &paths[0];
                info!(
                    "⚡ Opportunity: {} hops | profit={} wei | confidence={:.2}",
                    best.hops.len(),
                    best.expected_profit_wei,
                    best.confidence
                );

                // Execute best path
                let result = tx_executor
                    .execute_arb(best, risk.gas_price_gwei)
                    .await;

                // Persist result to SQLite
                if let Err(e) = db.record_execution(best, &result).await {
                    error!("DB write failed: {}", e);
                }

                if result.success {
                    info!(
                        "✅ Executed: tx={:?} profit={} wei gas={}",
                        result.tx_hash,
                        result.profit_wei,
                        result.gas_used
                    );
                } else {
                    warn!("❌ Execution failed: {:?}", result.error);
                }
            }
            Ok(_) => {} // No paths found — normal
            Err(e) => error!("Path finding error: {}", e),
        }
    }
}
