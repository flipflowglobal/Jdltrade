// crates/mempool_scanner/src/decoder.rs (continued)
        let deadline = tuple[4].clone().into_uint()?;
        let amount_in = tuple[5].clone().into_uint()?;
        let amount_out_min = tuple[6].clone().into_uint()?;

        Some(DecodedSwap {
            tx_hash: tx.hash,
            router,
            dex: DexType::UniswapV3,
            token_in: Token {
                address: token_in_addr,
                symbol: format!("0x{:x}", token_in_addr)[..8].to_string(),
                decimals: 18,
            },
            token_out: Token {
                address: token_out_addr,
                symbol: format!("0x{:x}", token_out_addr)[..8].to_string(),
                decimals: 18,
            },
            amount_in,
            amount_out_min,
            deadline,
            gas_price: tx.gas_price.unwrap_or_default(),
        })
    }

    fn decode_v3_multi(&self, tx: &Transaction, router: Address, data: &[u8]) -> Option<DecodedSwap> {
        // exactInput((path_bytes, recipient, deadline, amountIn, amountOutMinimum))
        let params = decode(
            &[ParamType::Tuple(vec![
                ParamType::Bytes,     // encoded path
                ParamType::Address,   // recipient
                ParamType::Uint(256), // deadline
                ParamType::Uint(256), // amountIn
                ParamType::Uint(256), // amountOutMinimum
            ])],
            data,
        ).ok()?;

        let tuple = match &params[0] {
            AbiToken::Tuple(t) => t.clone(),
            _ => return None,
        };

        let path_bytes = tuple[0].clone().into_bytes()?;
        let deadline = tuple[2].clone().into_uint()?;
        let amount_in = tuple[3].clone().into_uint()?;
        let amount_out_min = tuple[4].clone().into_uint()?;

        // V3 path encoding: [token0, fee(3b), token1, fee(3b), token2...]
        if path_bytes.len() < 43 {
            return None;
        }
        let token_in_addr = Address::from_slice(&path_bytes[0..20]);
        let token_out_addr = Address::from_slice(&path_bytes[path_bytes.len() - 20..]);

        Some(DecodedSwap {
            tx_hash: tx.hash,
            router,
            dex: DexType::UniswapV3,
            token_in: Token {
                address: token_in_addr,
                symbol: format!("0x{:x}", token_in_addr)[..8].to_string(),
                decimals: 18,
            },
            token_out: Token {
                address: token_out_addr,
                symbol: format!("0x{:x}", token_out_addr)[..8].to_string(),
                decimals: 18,
            },
            amount_in,
            amount_out_min,
            deadline,
            gas_price: tx.gas_price.unwrap_or_default(),
        })
    }
}
