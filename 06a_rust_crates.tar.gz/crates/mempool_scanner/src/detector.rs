// crates/mempool_scanner/src/detector.rs
//! Analyzes decoded swaps for MEV and arbitrage viability

use ethers::types::U256;
use crate::{DecodedSwap, SwapSignal};

// Min USD value to consider a swap worth acting on
const WETH_USD_PRICE: f64 = 3200.0;
const WEI_PER_ETH: f64 = 1e18;

pub struct MevDetector {
    pub sandwich_min_impact_bps: u32,
    pub min_gas_price_gwei: u64,
}

impl MevDetector {
    pub fn new() -> Self {
        Self {
            sandwich_min_impact_bps: 10, // 0.1% minimum price impact
            min_gas_price_gwei: 1,
        }
    }

    pub fn analyze(&self, swap: &DecodedSwap, min_amount_usd: f64) -> Option<SwapSignal> {
        let amount_eth = wei_to_eth(swap.amount_in);
        let amount_usd = amount_eth * WETH_USD_PRICE;

        if amount_usd < min_amount_usd {
            return None;
        }

        let estimated_price_impact = self.estimate_price_impact(swap);
        let sandwich_viable = estimated_price_impact >= (self.sandwich_min_impact_bps as f64 / 10000.0);
        let front_run_viable = amount_usd > 50_000.0;

        Some(SwapSignal {
            swap: swap.clone(),
            estimated_price_impact,
            sandwich_viable,
            front_run_viable,
        })
    }

    fn estimate_price_impact(&self, swap: &DecodedSwap) -> f64 {
        // Simplified: real impl would query on-chain reserves
        // Impact approximation: larger trades relative to typical liquidity
        let amount_eth = wei_to_eth(swap.amount_in);
        // Assume average pool liquidity ~$5M for Arbitrum mid-tier pools
        let assumed_liquidity_eth = 5_000_000.0 / WETH_USD_PRICE;
        (amount_eth / assumed_liquidity_eth).min(1.0)
    }
}

fn wei_to_eth(wei: U256) -> f64 {
    let as_u128 = wei.min(U256::from(u128::MAX)).as_u128();
    as_u128 as f64 / WEI_PER_ETH
}
