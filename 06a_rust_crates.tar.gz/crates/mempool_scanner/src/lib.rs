// crates/mempool_scanner/src/lib.rs
//! High-performance mempool scanner using ethers-rs WebSocket subscriptions.
//! Detects sandwich opportunities, large swaps, and front-runnable transactions.

use std::sync::Arc;
use std::time::Instant;

use anyhow::Result;
use chrono::Utc;
use dashmap::DashMap;
use ethers::{
    providers::{Middleware, Provider, StreamExt, Ws},
    types::{Address, Transaction, H256, U256},
};
use jdl_core::{
    metrics::{MEMPOOL_TX_RATE, ARB_OPPORTUNITIES_DETECTED},
    types::{MempoolTx, Token, DexType},
};
use tokio::sync::broadcast;
use tracing::{debug, info, warn};

pub mod decoder;
pub mod detector;

pub use decoder::SwapDecoder;
pub use detector::MevDetector;

/// Known DEX router addresses on Arbitrum
pub mod known_routers {
    use ethers::types::Address;
    use std::str::FromStr;

    pub fn uniswap_v2() -> Address {
        Address::from_str("0x4752ba5DBc23f44D87826276BF6Fd6b1C372aD24").unwrap()
    }
    pub fn uniswap_v3() -> Address {
        Address::from_str("0xE592427A0AEce92De3Edee1F18E0157C05861564").unwrap()
    }
    pub fn sushiswap() -> Address {
        Address::from_str("0x1b02dA8Cb0d097eB8D57A175b88c7D8b47997506").unwrap()
    }
    pub fn camelot() -> Address {
        Address::from_str("0xc873fEcbd354f5A56E00E710B90EF4201db2448d").unwrap()
    }

    pub fn all() -> Vec<Address> {
        vec![uniswap_v2(), uniswap_v3(), sushiswap(), camelot()]
    }
}

/// Decoded swap event from mempool tx
#[derive(Debug, Clone)]
pub struct DecodedSwap {
    pub tx_hash: H256,
    pub router: Address,
    pub dex: DexType,
    pub token_in: Token,
    pub token_out: Token,
    pub amount_in: U256,
    pub amount_out_min: U256,
    pub deadline: U256,
    pub gas_price: U256,
}

/// Signal emitted when a high-value swap is detected
#[derive(Debug, Clone)]
pub struct SwapSignal {
    pub swap: DecodedSwap,
    pub estimated_price_impact: f64,
    pub sandwich_viable: bool,
    pub front_run_viable: bool,
}

/// Main mempool scanner service
pub struct MempoolScanner {
    ws_url: String,
    swap_tx: broadcast::Sender<SwapSignal>,
    raw_tx: broadcast::Sender<MempoolTx>,
    seen_hashes: Arc<DashMap<H256, Instant>>,
    decoder: Arc<SwapDecoder>,
    detector: Arc<MevDetector>,
    min_amount_usd: f64,
}

impl MempoolScanner {
    pub fn new(
        ws_url: String,
        min_amount_usd: f64,
    ) -> (Self, broadcast::Receiver<SwapSignal>, broadcast::Receiver<MempoolTx>) {
        let (swap_tx, swap_rx) = broadcast::channel(1024);
        let (raw_tx, raw_rx) = broadcast::channel(4096);

        let scanner = Self {
            ws_url,
            swap_tx,
            raw_tx,
            seen_hashes: Arc::new(DashMap::new()),
            decoder: Arc::new(SwapDecoder::new()),
            detector: Arc::new(MevDetector::new()),
            min_amount_usd,
        };

        (scanner, swap_rx, raw_rx)
    }

    /// Start scanning — reconnects automatically on disconnect
    pub async fn run(&self) -> Result<()> {
        loop {
            match self.scan_once().await {
                Ok(_) => info!("Mempool scanner disconnected, reconnecting..."),
                Err(e) => warn!("Mempool scanner error: {}, reconnecting in 2s...", e),
            }
            tokio::time::sleep(tokio::time::Duration::from_secs(2)).await;
        }
    }

    async fn scan_once(&self) -> Result<()> {
        let provider = Provider::<Ws>::connect(&self.ws_url).await?;
        let provider = Arc::new(provider);

        info!("Mempool scanner connected to {}", self.ws_url);

        let mut stream = provider.subscribe_pending_txs().await?;
        let mut tx_count = 0u64;
        let mut rate_timer = Instant::now();

        while let Some(tx_hash) = stream.next().await {
            // Skip already seen
            if self.seen_hashes.contains_key(&tx_hash) {
                continue;
            }
            self.seen_hashes.insert(tx_hash, Instant::now());

            // Rate tracking
            tx_count += 1;
            if rate_timer.elapsed().as_secs() >= 1 {
                MEMPOOL_TX_RATE.set(tx_count as f64);
                tx_count = 0;
                rate_timer = Instant::now();
                // Prune old hashes (> 60s)
                self.seen_hashes.retain(|_, v| v.elapsed().as_secs() < 60);
            }

            let provider_clone = provider.clone();
            let swap_tx = self.swap_tx.clone();
            let raw_tx = self.raw_tx.clone();
            let decoder = self.decoder.clone();
            let detector = self.detector.clone();
            let min_amount_usd = self.min_amount_usd;

            // Spawn per-tx processing — non-blocking
            tokio::spawn(async move {
                if let Ok(Some(tx)) = provider_clone.get_transaction(tx_hash).await {
                    let mempool_tx = tx_to_mempool(&tx);

                    // Broadcast raw tx
                    let _ = raw_tx.send(mempool_tx.clone());

                    // Try to decode as swap
                    if let Some(swap) = decoder.decode_swap(&tx) {
                        debug!("Decoded swap: {:?} -> {:?}", swap.token_in.symbol, swap.token_out.symbol);

                        // Check if MEV-viable
                        if let Some(signal) = detector.analyze(&swap, min_amount_usd) {
                            ARB_OPPORTUNITIES_DETECTED.inc();
                            let _ = swap_tx.send(signal);
                        }
                    }
                }
            });
        }

        Ok(())
    }
}

fn tx_to_mempool(tx: &Transaction) -> MempoolTx {
    MempoolTx {
        hash: tx.hash,
        from: tx.from,
        to: tx.to,
        value: tx.value,
        gas_price: tx.gas_price.unwrap_or_default(),
        max_fee_per_gas: tx.max_fee_per_gas,
        max_priority_fee: tx.max_priority_fee_per_gas,
        input: tx.input.to_vec(),
        nonce: tx.nonce,
        detected_at: Utc::now(),
    }
}
