// crates/jdl_core/src/errors.rs
use thiserror::Error;

#[derive(Error, Debug)]
pub enum JdlError {
    #[error("RPC connection failed: {0}")]
    RpcError(String),

    #[error("Insufficient liquidity in pool {pool}: needed {needed}, available {available}")]
    InsufficientLiquidity {
        pool: String,
        needed: String,
        available: String,
    },

    #[error("Arbitrage no longer profitable after simulation: expected {expected_wei} wei, got {actual_wei} wei")]
    UnprofitableAfterSim {
        expected_wei: i128,
        actual_wei: i128,
    },

    #[error("Circuit breaker open: daily loss limit reached")]
    CircuitBreakerOpen,

    #[error("Gas price {current_gwei} gwei exceeds max {max_gwei} gwei")]
    GasPriceTooHigh { current_gwei: u64, max_gwei: u64 },

    #[error("Oracle manipulation detected on {token}: price deviation {deviation_pct:.2}%")]
    OracleManipulation {
        token: String,
        deviation_pct: f64,
    },

    #[error("Flash loan failed: {0}")]
    FlashLoanError(String),

    #[error("Transaction reverted: {0}")]
    TxReverted(String),

    #[error("Slippage exceeded: expected {expected_bps} bps, got {actual_bps} bps")]
    SlippageExceeded {
        expected_bps: u32,
        actual_bps: u32,
    },

    #[error("Path finding failed: no profitable path found in {elapsed_ms}ms")]
    NoPathFound { elapsed_ms: u64 },

    #[error("Config error: {0}")]
    ConfigError(String),

    #[error("Database error: {0}")]
    DatabaseError(String),

    #[error(transparent)]
    Anyhow(#[from] anyhow::Error),
}

// crates/jdl_core/src/metrics.rs
