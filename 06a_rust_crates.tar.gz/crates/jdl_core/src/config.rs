// crates/jdl_core/src/config.rs
use ethers::types::Address;
use rust_decimal::Decimal;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct JdlConfig {
    pub network: NetworkConfig,
    pub execution: ExecutionConfig,
    pub risk: RiskConfig,
    pub flash_loan: FlashLoanConfig,
    pub monitoring: MonitoringConfig,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NetworkConfig {
    pub rpc_ws_url: String,
    pub rpc_http_url: String,
    pub chain_id: u64,
    pub block_time_ms: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExecutionConfig {
    pub min_profit_usd: Decimal,
    pub max_slippage_bps: u32,
    pub deadline_secs: u64,
    pub max_hops: usize,
    pub dry_run: bool,
    pub private_key_env: String, // env var name, never store key directly
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RiskConfig {
    pub max_position_usd: Decimal,
    pub max_daily_loss_usd: Decimal,
    pub circuit_breaker_loss_pct: f64,
    pub max_gas_gwei: u64,
    pub min_oracle_health: f64,
    pub max_network_congestion: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FlashLoanConfig {
    pub aave_pool: Address,
    pub balancer_vault: Address,
    pub receiver_contract: Address,
    pub preferred_provider: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MonitoringConfig {
    pub metrics_port: u16,
    pub log_level: String,
    pub alert_webhook: Option<String>,
    pub sqlite_path: String,
}

impl JdlConfig {
    pub fn from_env() -> anyhow::Result<Self> {
        let config_path = std::env::var("JDL_CONFIG_PATH")
            .unwrap_or_else(|_| "config/jdl_config.json".to_string());
        let raw = std::fs::read_to_string(&config_path)?;
        Ok(serde_json::from_str(&raw)?)
    }
}

// crates/jdl_core/src/errors.rs
