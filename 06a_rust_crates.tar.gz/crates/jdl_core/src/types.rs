// crates/jdl_core/src/types.rs
use chrono::{DateTime, Utc};
use ethers::types::{Address, H256, U256};
use rust_decimal::Decimal;
use serde::{Deserialize, Serialize};
use uuid::Uuid;

/// Represents a token in the ecosystem
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)]
pub struct Token {
    pub address: Address,
    pub symbol: String,
    pub decimals: u8,
}

/// A liquidity pool (Uniswap V2/V3, Sushiswap, Camelot, etc.)
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Pool {
    pub address: Address,
    pub dex: DexType,
    pub token0: Token,
    pub token1: Token,
    pub reserve0: U256,
    pub reserve1: U256,
    pub fee_bps: u32, // basis points e.g. 30 = 0.3%
    pub sqrt_price_x96: Option<U256>, // V3 only
    pub liquidity: Option<U256>,      // V3 only
    pub tick: Option<i32>,            // V3 only
    pub last_updated: DateTime<Utc>,
}

impl Pool {
    /// Calculate spot price token0 → token1 (V2 constant product)
    pub fn spot_price_v2(&self) -> Option<Decimal> {
        if self.reserve0.is_zero() || self.reserve1.is_zero() {
            return None;
        }
        let r0 = Decimal::from(self.reserve0.as_u128());
        let r1 = Decimal::from(self.reserve1.as_u128());
        Some(r1 / r0)
    }

    /// Compute V2 output amount with fee
    pub fn get_amount_out_v2(&self, amount_in: U256) -> U256 {
        let fee_multiplier = 10000u64 - self.fee_bps as u64;
        let amount_in_with_fee = amount_in * fee_multiplier;
        let numerator = amount_in_with_fee * self.reserve1;
        let denominator = self.reserve0 * 10000u64 + amount_in_with_fee;
        numerator / denominator
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)]
pub enum DexType {
    UniswapV2,
    UniswapV3,
    SushiSwap,
    Camelot,
    Balancer,
    Curve,
    Custom(String),
}

/// An arbitrage path: sequence of swaps across pools
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ArbPath {
    pub id: Uuid,
    pub hops: Vec<Hop>,
    pub input_token: Token,
    pub input_amount: U256,
    pub expected_output: U256,
    pub expected_profit_wei: i128,
    pub expected_profit_usd: Decimal,
    pub gas_estimate: u64,
    pub confidence: f64,
    pub detected_at: DateTime<Utc>,
}

impl ArbPath {
    pub fn net_profit_after_gas(&self, gas_price_gwei: u64) -> i128 {
        let gas_cost_wei = (self.gas_estimate as i128) * (gas_price_gwei as i128) * 1_000_000_000;
        self.expected_profit_wei - gas_cost_wei
    }

    pub fn is_profitable(&self, gas_price_gwei: u64, min_profit_wei: i128) -> bool {
        self.net_profit_after_gas(gas_price_gwei) >= min_profit_wei
    }
}

/// A single swap hop in an arb path
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Hop {
    pub pool: Address,
    pub dex: DexType,
    pub token_in: Token,
    pub token_out: Token,
    pub amount_in: U256,
    pub amount_out_min: U256,
}

/// Mempool transaction observation
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MempoolTx {
    pub hash: H256,
    pub from: Address,
    pub to: Option<Address>,
    pub value: U256,
    pub gas_price: U256,
    pub max_fee_per_gas: Option<U256>,
    pub max_priority_fee: Option<U256>,
    pub input: Vec<u8>,
    pub nonce: U256,
    pub detected_at: DateTime<Utc>,
}

/// Flash loan parameters
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FlashLoanParams {
    pub provider: FlashLoanProvider,
    pub token: Token,
    pub amount: U256,
    pub fee_bps: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum FlashLoanProvider {
    AaveV3,
    Balancer,
    UniswapV3,
}

/// Execution result from tx_executor
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ExecutionResult {
    pub tx_hash: Option<H256>,
    pub success: bool,
    pub profit_wei: i128,
    pub gas_used: u64,
    pub error: Option<String>,
    pub executed_at: DateTime<Utc>,
}

/// Market regime classification (feeds from Python PPO)
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum MarketRegime {
    HighVolatility,
    LowVolatility,
    Trending,
    Ranging,
    Stressed,
}

/// Risk signal passed from risk engine
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RiskSignal {
    pub regime: MarketRegime,
    pub gas_price_gwei: u64,
    pub network_congestion: f64, // 0.0 - 1.0
    pub oracle_health: f64,      // 0.0 - 1.0
    pub circuit_breaker_open: bool,
    pub max_position_wei: U256,
    pub timestamp: DateTime<Utc>,
}
