// crates/jdl_core/src/metrics.rs
use lazy_static::lazy_static;
use prometheus::{
    register_counter, register_gauge, register_histogram,
    Counter, Gauge, Histogram, HistogramOpts, Opts,
};

lazy_static! {
    pub static ref ARB_OPPORTUNITIES_DETECTED: Counter = register_counter!(
        Opts::new("jdl_arb_opportunities_detected_total", "Total arbitrage opportunities detected")
    ).unwrap();

    pub static ref ARB_EXECUTIONS_ATTEMPTED: Counter = register_counter!(
        Opts::new("jdl_arb_executions_attempted_total", "Total arbitrage executions attempted")
    ).unwrap();

    pub static ref ARB_EXECUTIONS_SUCCESS: Counter = register_counter!(
        Opts::new("jdl_arb_executions_success_total", "Successful arbitrage executions")
    ).unwrap();

    pub static ref TOTAL_PROFIT_WEI: Gauge = register_gauge!(
        Opts::new("jdl_total_profit_wei", "Cumulative profit in wei")
    ).unwrap();

    pub static ref CURRENT_GAS_GWEI: Gauge = register_gauge!(
        Opts::new("jdl_current_gas_gwei", "Current gas price in gwei")
    ).unwrap();

    pub static ref MEMPOOL_TX_RATE: Gauge = register_gauge!(
        Opts::new("jdl_mempool_tx_per_second", "Mempool transactions per second")
    ).unwrap();

    pub static ref PATH_FINDING_LATENCY_MS: Histogram = register_histogram!(
        HistogramOpts::new("jdl_path_finding_latency_ms", "Path finding latency in milliseconds")
            .buckets(vec![0.1, 0.5, 1.0, 2.0, 5.0, 10.0, 25.0, 50.0, 100.0])
    ).unwrap();

    pub static ref EXECUTION_LATENCY_MS: Histogram = register_histogram!(
        HistogramOpts::new("jdl_execution_latency_ms", "Transaction execution latency in ms")
            .buckets(vec![10.0, 50.0, 100.0, 250.0, 500.0, 1000.0, 3000.0])
    ).unwrap();

    pub static ref CIRCUIT_BREAKER_STATE: Gauge = register_gauge!(
        Opts::new("jdl_circuit_breaker_open", "Circuit breaker state (1=open, 0=closed)")
    ).unwrap();

    pub static ref POOL_RESERVE_STALENESS_SECS: Histogram = register_histogram!(
        HistogramOpts::new("jdl_pool_reserve_staleness_secs", "Age of pool reserve data in seconds")
            .buckets(vec![0.1, 0.5, 1.0, 2.0, 5.0, 10.0, 30.0, 60.0])
    ).unwrap();
}

pub async fn serve_metrics(port: u16) -> anyhow::Result<()> {
    use prometheus::Encoder;
    use tokio::net::TcpListener;
    use tokio::io::AsyncWriteExt;

    let listener = TcpListener::bind(format!("0.0.0.0:{}", port)).await?;
    tracing::info!("Metrics server listening on :{}", port);

    loop {
        let (mut socket, _) = listener.accept().await?;
        tokio::spawn(async move {
            let encoder = prometheus::TextEncoder::new();
            let metric_families = prometheus::gather();
            let mut buffer = Vec::new();
            encoder.encode(&metric_families, &mut buffer).unwrap();

            let response = format!(
                "HTTP/1.1 200 OK\r\nContent-Type: text/plain; version=0.0.4\r\nContent-Length: {}\r\n\r\n",
                buffer.len()
            );
            let _ = socket.write_all(response.as_bytes()).await;
            let _ = socket.write_all(&buffer).await;
        });
    }
}
