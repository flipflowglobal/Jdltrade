// crates/pyo3_bridge/src/lib.rs
//! Exposes critical Rust hot-paths to the existing Python JDL system via PyO3.
//! Import in Python: import jdl_rust
//!
//! Usage from Python:
//!   import jdl_rust
//!   engine = jdl_rust.RustArbEngine("wss://...", "http://...", min_profit_wei=100000)
//!   paths = engine.find_arb_paths(token_in_addr, amount_wei_str, gas_gwei)
//!   engine.update_pool(pool_json_str)

use pyo3::prelude::*;
use pyo3::exceptions::{PyRuntimeError, PyValueError};
use std::sync::Arc;
use tokio::runtime::Runtime;
use ethers::types::{Address, U256};
use std::str::FromStr;
use serde_json::Value;

use path_finder::PathFinder;
use risk_engine::RiskEngine;
use jdl_core::{
    config::RiskConfig,
    types::{DexType, Pool, Token, RiskSignal},
};

/// Main Python-facing arbitrage engine
#[pyclass]
pub struct RustArbEngine {
    path_finder: Arc<PathFinder>,
    risk_engine: Arc<RiskEngine>,
    runtime: Arc<Runtime>,
}

#[pymethods]
impl RustArbEngine {
    #[new]
    #[pyo3(signature = (rpc_ws_url, rpc_http_url, min_profit_wei=100_000_000_000_000i64, max_hops=3))]
    fn new(
        rpc_ws_url: String,
        rpc_http_url: String,
        min_profit_wei: i64,
        max_hops: usize,
    ) -> PyResult<Self> {
        let runtime = Runtime::new()
            .map_err(|e| PyRuntimeError::new_err(format!("Tokio runtime error: {}", e)))?;

        let risk_config = RiskConfig {
            max_position_usd: rust_decimal::Decimal::from(50_000u64),
            max_daily_loss_usd: rust_decimal::Decimal::from(5_000u64),
            circuit_breaker_loss_pct: 0.1,
            max_gas_gwei: 50,
            min_oracle_health: 0.9,
            max_network_congestion: 0.8,
        };

        let path_finder = Arc::new(PathFinder::new(max_hops, min_profit_wei as i128));
        let risk_engine = Arc::new(RiskEngine::new(risk_config));

        Ok(Self {
            path_finder,
            risk_engine,
            runtime: Arc::new(runtime),
        })
    }

    /// Add or update a pool from JSON string.
    /// Called from Python whenever a Sync event is detected.
    ///
    /// pool_json format:
    /// {
    ///   "address": "0x...", "dex": "UniswapV2",
    ///   "token0": {"address": "0x...", "symbol": "WETH", "decimals": 18},
    ///   "token1": {"address": "0x...", "symbol": "USDC", "decimals": 6},
    ///   "reserve0": "1000000000000000000",
    ///   "reserve1": "3200000000",
    ///   "fee_bps": 30
    /// }
    fn update_pool(&self, pool_json: &str) -> PyResult<()> {
        let v: Value = serde_json::from_str(pool_json)
            .map_err(|e| PyValueError::new_err(format!("Invalid pool JSON: {}", e)))?;

        let pool = parse_pool_json(&v)
            .map_err(|e| PyValueError::new_err(format!("Pool parse error: {}", e)))?;

        let pf = self.path_finder.clone();
        self.runtime.block_on(async move {
            pf.add_pool(pool).await;
        });

        Ok(())
    }

    /// Update reserves for a known pool (fast path for Sync events)
    fn update_reserves(
        &self,
        pool_address: &str,
        reserve0_str: &str,
        reserve1_str: &str,
    ) -> PyResult<()> {
        let addr = Address::from_str(pool_address)
            .map_err(|e| PyValueError::new_err(format!("Invalid address: {}", e)))?;
        let r0 = U256::from_dec_str(reserve0_str)
            .map_err(|e| PyValueError::new_err(format!("Invalid reserve0: {}", e)))?;
        let r1 = U256::from_dec_str(reserve1_str)
            .map_err(|e| PyValueError::new_err(format!("Invalid reserve1: {}", e)))?;

        let pf = self.path_finder.clone();
        self.runtime.block_on(async move {
            pf.update_pool_reserves(addr, r0, r1).await;
        });

        Ok(())
    }

    /// Find arbitrage paths and return as JSON string list.
    /// Returns: JSON array of ArbPath objects
    fn find_arb_paths(
        &self,
        token_in_address: &str,
        amount_wei_str: &str,
        gas_price_gwei: u64,
    ) -> PyResult<String> {
        let addr = Address::from_str(token_in_address)
            .map_err(|e| PyValueError::new_err(format!("Invalid token address: {}", e)))?;
        let amount = U256::from_dec_str(amount_wei_str)
            .map_err(|e| PyValueError::new_err(format!("Invalid amount: {}", e)))?;

        let token_in = Token {
            address: addr,
            symbol: "INPUT".to_string(),
            decimals: 18,
        };

        let pf = self.path_finder.clone();
        let re = self.risk_engine.clone();

        let paths = self.runtime.block_on(async move {
            let risk = re.current().await;
            pf.find_opportunities(&token_in, amount, gas_price_gwei, &risk).await
        }).map_err(|e| PyRuntimeError::new_err(format!("Path finding error: {}", e)))?;

        let json = serde_json::to_string(&paths)
            .map_err(|e| PyRuntimeError::new_err(format!("Serialization error: {}", e)))?;

        Ok(json)
    }

    /// Update gas price and get congestion score
    fn update_gas_price(&self, gas_gwei: u64) -> PyResult<f64> {
        let re = self.risk_engine.clone();
        let congestion = self.runtime.block_on(async move {
            re.update_gas(gas_gwei).await;
            let signal = re.current().await;
            signal.network_congestion
        });
        Ok(congestion)
    }

    /// Update price observation and check oracle health
    /// Returns: True if oracle is healthy, False if manipulation detected
    fn update_price(
        &self,
        dex_price: f64,
        chainlink_price: Option<f64>,
    ) -> PyResult<bool> {
        let re = self.risk_engine.clone();
        let healthy = self.runtime.block_on(async move {
            re.update_price(dex_price, chainlink_price).await
        });
        Ok(healthy)
    }

    /// Get current risk signal as JSON
    fn get_risk_signal(&self) -> PyResult<String> {
        let re = self.risk_engine.clone();
        let signal = self.runtime.block_on(async move {
            re.current().await
        });
        let json = serde_json::to_string(&signal)
            .map_err(|e| PyRuntimeError::new_err(format!("Serialization error: {}", e)))?;
        Ok(json)
    }

    /// Trip circuit breaker manually
    fn open_circuit_breaker(&self) -> PyResult<()> {
        let re = self.risk_engine.clone();
        self.runtime.block_on(async move {
            re.open_circuit_breaker().await;
        });
        Ok(())
    }

    /// Reset circuit breaker and daily loss counter
    fn close_circuit_breaker(&self) -> PyResult<()> {
        let re = self.risk_engine.clone();
        self.runtime.block_on(async move {
            re.close_circuit_breaker().await;
        });
        Ok(())
    }

    /// Get pool count in registry
    fn pool_count(&self) -> PyResult<usize> {
        let pf = self.path_finder.clone();
        let count = self.runtime.block_on(async move {
            pf.registry.read().await.len()
        });
        Ok(count)
    }
}

fn parse_pool_json(v: &Value) -> anyhow::Result<Pool> {
    use chrono::Utc;

    let address = Address::from_str(v["address"].as_str().unwrap_or(""))?;

    let dex = match v["dex"].as_str().unwrap_or("UniswapV2") {
        "UniswapV3" => DexType::UniswapV3,
        "SushiSwap" => DexType::SushiSwap,
        "Camelot" => DexType::Camelot,
        _ => DexType::UniswapV2,
    };

    let token0 = Token {
        address: Address::from_str(v["token0"]["address"].as_str().unwrap_or("0x0000000000000000000000000000000000000000"))?,
        symbol: v["token0"]["symbol"].as_str().unwrap_or("TKN0").to_string(),
        decimals: v["token0"]["decimals"].as_u64().unwrap_or(18) as u8,
    };

    let token1 = Token {
        address: Address::from_str(v["token1"]["address"].as_str().unwrap_or("0x0000000000000000000000000000000000000000"))?,
        symbol: v["token1"]["symbol"].as_str().unwrap_or("TKN1").to_string(),
        decimals: v["token1"]["decimals"].as_u64().unwrap_or(18) as u8,
    };

    let reserve0 = U256::from_dec_str(v["reserve0"].as_str().unwrap_or("0"))?;
    let reserve1 = U256::from_dec_str(v["reserve1"].as_str().unwrap_or("0"))?;
    let fee_bps = v["fee_bps"].as_u64().unwrap_or(30) as u32;

    Ok(Pool {
        address,
        dex,
        token0,
        token1,
        reserve0,
        reserve1,
        fee_bps,
        sqrt_price_x96: None,
        liquidity: None,
        tick: None,
        last_updated: Utc::now(),
    })
}

/// Register the Python module
#[pymodule]
fn jdl_rust(_py: Python, m: &PyModule) -> PyResult<()> {
    m.add_class::<RustArbEngine>()?;
    Ok(())
}
