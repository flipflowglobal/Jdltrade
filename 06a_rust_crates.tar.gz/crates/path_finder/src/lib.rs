// crates/path_finder/src/lib.rs
//! Arbitrage path detection using Bellman-Ford on a weighted DEX graph.
//! Negative cycle = arbitrage opportunity.
//! Uses rayon for parallel edge relaxation across pool universe.

pub mod graph;
pub mod simulator;
pub mod pool_registry;

pub use graph::{ArbGraph, EdgeWeight};
pub use simulator::PathSimulator;
pub use pool_registry::PoolRegistry;

use std::sync::Arc;
use anyhow::Result;
use chrono::Utc;
use ethers::types::{Address, U256};
use jdl_core::{
    metrics::{PATH_FINDING_LATENCY_MS, ARB_OPPORTUNITIES_DETECTED},
    types::{ArbPath, Hop, Pool, RiskSignal, Token},
};
use tokio::sync::RwLock;
use tracing::{debug, info};
use uuid::Uuid;
use std::time::Instant;

/// Main path finding service
pub struct PathFinder {
    pub registry: Arc<RwLock<PoolRegistry>>,
    pub graph: Arc<RwLock<ArbGraph>>,
    pub simulator: Arc<PathSimulator>,
    pub max_hops: usize,
    pub min_profit_wei: i128,
}

impl PathFinder {
    pub fn new(max_hops: usize, min_profit_wei: i128) -> Self {
        Self {
            registry: Arc::new(RwLock::new(PoolRegistry::new())),
            graph: Arc::new(RwLock::new(ArbGraph::new())),
            simulator: Arc::new(PathSimulator::new()),
            max_hops,
            min_profit_wei,
        }
    }

    /// Register a pool and update graph edges
    pub async fn add_pool(&self, pool: Pool) {
        let mut registry = self.registry.write().await;
        registry.insert(pool.clone());

        let mut graph = self.graph.write().await;
        graph.update_pool_edges(&pool);
    }

    /// Update reserves for existing pool (called on Sync events)
    pub async fn update_pool_reserves(
        &self,
        pool_address: Address,
        reserve0: U256,
        reserve1: U256,
    ) {
        let mut registry = self.registry.write().await;
        if let Some(pool) = registry.get_mut(&pool_address) {
            pool.reserve0 = reserve0;
            pool.reserve1 = reserve1;
            pool.last_updated = Utc::now();

            let pool_clone = pool.clone();
            drop(registry);

            let mut graph = self.graph.write().await;
            graph.update_pool_edges(&pool_clone);
        }
    }

    /// Run Bellman-Ford to find all negative cycles (arb opportunities)
    pub async fn find_opportunities(
        &self,
        input_token: &Token,
        input_amount: U256,
        gas_price_gwei: u64,
        risk: &RiskSignal,
    ) -> Result<Vec<ArbPath>> {
        if risk.circuit_breaker_open {
            return Ok(vec![]);
        }

        let start = Instant::now();
        let graph = self.graph.read().await;
        let registry = self.registry.read().await;

        let paths = graph.bellman_ford_arb(
            input_token,
            input_amount,
            self.max_hops,
            &registry,
        );

        let elapsed_ms = start.elapsed().as_millis() as f64;
        PATH_FINDING_LATENCY_MS.observe(elapsed_ms);

        // Filter and simulate each candidate path
        let mut profitable = Vec::new();

        for candidate in paths {
            let simulated = self.simulator.simulate(&candidate, &registry).await?;

            if simulated.is_profitable(gas_price_gwei, self.min_profit_wei) {
                ARB_OPPORTUNITIES_DETECTED.inc();
                debug!(
                    "Profitable path found: {} hops, profit={} wei, latency={}ms",
                    simulated.hops.len(),
                    simulated.expected_profit_wei,
                    elapsed_ms
                );
                profitable.push(simulated);
            }
        }

        // Sort by net profit descending
        profitable.sort_by(|a, b| {
            b.net_profit_after_gas(gas_price_gwei)
                .cmp(&a.net_profit_after_gas(gas_price_gwei))
        });

        info!(
            "Path search complete: {}ms, {} candidates, {} profitable",
            elapsed_ms,
            graph.edge_count(),
            profitable.len()
        );

        Ok(profitable)
    }
}
