// crates/path_finder/src/graph.rs
//! Weighted directed graph over DEX pools.
//! Edge weight = -log(exchange_rate * (1 - fee))
//! Negative cycle detection via Bellman-Ford = arbitrage opportunity.

use std::collections::HashMap;
use chrono::Utc;
use ethers::types::{Address, U256};
use jdl_core::types::{ArbPath, DexType, Hop, Pool, Token};
use rayon::prelude::*;
use rust_decimal::Decimal;
use uuid::Uuid;

pub type NodeId = Address; // token address is the graph node

#[derive(Debug, Clone)]
pub struct EdgeWeight {
    pub pool: Address,
    pub dex: DexType,
    pub token_in: Token,
    pub token_out: Token,
    pub weight: f64,        // -log(rate * (1-fee)) — negative = profitable direction
    pub rate: f64,          // effective exchange rate
    pub reserve_in: U256,
    pub reserve_out: U256,
    pub fee_bps: u32,
}

#[derive(Debug)]
pub struct ArbGraph {
    // adjacency: token_in -> Vec<(token_out, EdgeWeight)>
    edges: HashMap<NodeId, Vec<(NodeId, EdgeWeight)>>,
    // pool_address -> edges it contributes (for fast update)
    pool_edge_index: HashMap<Address, Vec<(NodeId, NodeId)>>,
}

impl ArbGraph {
    pub fn new() -> Self {
        Self {
            edges: HashMap::new(),
            pool_edge_index: HashMap::new(),
        }
    }

    pub fn edge_count(&self) -> usize {
        self.edges.values().map(|v| v.len()).sum()
    }

    /// Insert or update edges for a pool (bidirectional)
    pub fn update_pool_edges(&mut self, pool: &Pool) {
        // Remove old edges for this pool
        if let Some(old_edges) = self.pool_edge_index.get(&pool.address) {
            for (from, to) in old_edges.clone() {
                if let Some(adj) = self.edges.get_mut(&from) {
                    adj.retain(|(t, e)| !(t == &to && e.pool == pool.address));
                }
            }
        }

        let mut new_index = Vec::new();

        // token0 -> token1
        if let Some(edge01) = self.make_edge(pool, &pool.token0, &pool.token1) {
            self.edges
                .entry(pool.token0.address)
                .or_default()
                .push((pool.token1.address, edge01));
            new_index.push((pool.token0.address, pool.token1.address));
        }

        // token1 -> token0
        if let Some(edge10) = self.make_edge(pool, &pool.token1, &pool.token0) {
            self.edges
                .entry(pool.token1.address)
                .or_default()
                .push((pool.token0.address, edge10));
            new_index.push((pool.token1.address, pool.token0.address));
        }

        self.pool_edge_index.insert(pool.address, new_index);
    }

    fn make_edge(&self, pool: &Pool, token_in: &Token, token_out: &Token) -> Option<EdgeWeight> {
        if pool.reserve0.is_zero() || pool.reserve1.is_zero() {
            return None;
        }

        let (reserve_in, reserve_out) = if token_in.address == pool.token0.address {
            (pool.reserve0, pool.reserve1)
        } else {
            (pool.reserve1, pool.reserve0)
        };

        let r_in = reserve_in.as_u128() as f64;
        let r_out = reserve_out.as_u128() as f64;
        let fee_multiplier = 1.0 - (pool.fee_bps as f64 / 10000.0);
        let rate = (r_out / r_in) * fee_multiplier;

        if rate <= 0.0 || !rate.is_finite() {
            return None;
        }

        // Weight = -ln(rate): negative weight = profitable, positive = loss
        let weight = -rate.ln();

        Some(EdgeWeight {
            pool: pool.address,
            dex: pool.dex.clone(),
            token_in: token_in.clone(),
            token_out: token_out.clone(),
            weight,
            rate,
            reserve_in,
            reserve_out,
            fee_bps: pool.fee_bps,
        })
    }

    /// Bellman-Ford shortest path / negative cycle detection
    /// Returns candidate ArbPath structs for all negative cycles reachable from input_token
    pub fn bellman_ford_arb(
        &self,
        start_token: &Token,
        input_amount: U256,
        max_hops: usize,
        registry: &super::pool_registry::PoolRegistry,
    ) -> Vec<ArbPath> {
        let nodes: Vec<NodeId> = self.edges.keys().cloned().collect();
        let n = nodes.len();
        if n == 0 {
            return vec![];
        }

        let node_idx: HashMap<NodeId, usize> = nodes
            .iter()
            .enumerate()
            .map(|(i, &addr)| (addr, i))
            .collect();

        let start_idx = match node_idx.get(&start_token.address) {
            Some(&i) => i,
            None => return vec![],
        };

        // Distance array initialized to +infinity except start node
        let mut dist = vec![f64::INFINITY; n];
        let mut prev: Vec<Option<(usize, EdgeWeight)>> = vec![None; n];
        dist[start_idx] = 0.0;

        // Relax edges (max_hops - 1) times
        for _ in 0..max_hops.saturating_sub(1) {
            let mut updated = false;
            for (from_addr, adj) in &self.edges {
                let from_idx = match node_idx.get(from_addr) {
                    Some(&i) => i,
                    None => continue,
                };
                if dist[from_idx] == f64::INFINITY {
                    continue;
                }
                for (to_addr, edge) in adj {
                    let to_idx = match node_idx.get(to_addr) {
                        Some(&i) => i,
                        None => continue,
                    };
                    let new_dist = dist[from_idx] + edge.weight;
                    if new_dist < dist[to_idx] {
                        dist[to_idx] = new_dist;
                        prev[to_idx] = Some((from_idx, edge.clone()));
                        updated = true;
                    }
                }
            }
            if !updated {
                break; // Converged early
            }
        }

        // One more relaxation pass — any node that still gets updated is in a negative cycle
        let mut arb_paths = Vec::new();

        for (from_addr, adj) in &self.edges {
            let from_idx = match node_idx.get(from_addr) {
                Some(&i) => i,
                None => continue,
            };
            if dist[from_idx] == f64::INFINITY {
                continue;
            }
            for (to_addr, edge) in adj {
                let to_idx = match node_idx.get(to_addr) {
                    Some(&i) => i,
                    None => continue,
                };
                let new_dist = dist[from_idx] + edge.weight;
                if new_dist < dist[to_idx] {
                    // Negative cycle found — reconstruct path
                    if let Some(path) = self.reconstruct_path(
                        to_idx,
                        &prev,
                        &nodes,
                        start_token,
                        input_amount,
                        max_hops,
                    ) {
                        arb_paths.push(path);
                    }
                }
            }
        }

        arb_paths
    }

    fn reconstruct_path(
        &self,
        mut node_idx: usize,
        prev: &[Option<(usize, EdgeWeight)>],
        nodes: &[NodeId],
        start_token: &Token,
        input_amount: U256,
        max_hops: usize,
    ) -> Option<ArbPath> {
        let mut hops: Vec<Hop> = Vec::new();
        let mut visited = vec![false; nodes.len()];
        let mut current_amount = input_amount;

        // Trace back through predecessor chain
        let mut steps = 0;
        loop {
            if steps > max_hops || visited[node_idx] {
                break;
            }
            visited[node_idx] = true;

            match &prev[node_idx] {
                None => break,
                Some((prev_idx, edge)) => {
                    let amount_out = self.compute_amount_out(edge, current_amount);
                    hops.push(Hop {
                        pool: edge.pool,
                        dex: edge.dex.clone(),
                        token_in: edge.token_in.clone(),
                        token_out: edge.token_out.clone(),
                        amount_in: current_amount,
                        amount_out_min: amount_out * 995u64 / 1000u64, // 0.5% slippage buffer
                    });
                    current_amount = amount_out;
                    node_idx = *prev_idx;
                }
            }
            steps += 1;
        }

        if hops.is_empty() || hops.len() > max_hops {
            return None;
        }

        hops.reverse();

        let output = current_amount;
        let input_u128 = input_amount.min(U256::from(u128::MAX)).as_u128() as i128;
        let output_u128 = output.min(U256::from(u128::MAX)).as_u128() as i128;
        let profit_wei = output_u128 - input_u128;

        if profit_wei <= 0 {
            return None;
        }

        Some(ArbPath {
            id: Uuid::new_v4(),
            hops,
            input_token: start_token.clone(),
            input_amount,
            expected_output: output,
            expected_profit_wei: profit_wei,
            expected_profit_usd: rust_decimal::Decimal::from(0), // filled by simulator
            gas_estimate: 250_000 + (steps as u64 * 80_000),
            confidence: 0.85,
            detected_at: Utc::now(),
        })
    }

    fn compute_amount_out(&self, edge: &EdgeWeight, amount_in: U256) -> U256 {
        // Constant product formula with fee
        let fee_num = 10000u64 - edge.fee_bps as u64;
        let ain_with_fee = amount_in * fee_num;
        let r_in = edge.reserve_in;
        let r_out = edge.reserve_out;
        let numerator = ain_with_fee * r_out;
        let denominator = r_in * 10000u64 + ain_with_fee;
        if denominator.is_zero() {
            U256::zero()
        } else {
            numerator / denominator
        }
    }
}
