// crates/path_finder/src/pool_registry.rs
use std::collections::HashMap;
use ethers::types::Address;
use jdl_core::types::Pool;

pub struct PoolRegistry {
    pools: HashMap<Address, Pool>,
}

impl PoolRegistry {
    pub fn new() -> Self {
        Self { pools: HashMap::new() }
    }

    pub fn insert(&mut self, pool: Pool) {
        self.pools.insert(pool.address, pool);
    }

    pub fn get(&self, addr: &Address) -> Option<&Pool> {
        self.pools.get(addr)
    }

    pub fn get_mut(&mut self, addr: &Address) -> Option<&mut Pool> {
        self.pools.get_mut(addr)
    }

    pub fn len(&self) -> usize {
        self.pools.len()
    }

    pub fn all(&self) -> impl Iterator<Item = &Pool> {
        self.pools.values()
    }
}

// crates/path_finder/src/simulator.rs
