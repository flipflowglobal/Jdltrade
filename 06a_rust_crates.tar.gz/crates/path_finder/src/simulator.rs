// crates/path_finder/src/simulator.rs
//! Simulates full arb path execution off-chain before committing to tx.
//! Re-computes each hop using current reserves to catch stale graph state.

use anyhow::Result;
use chrono::Utc;
use ethers::types::U256;
use jdl_core::types::{ArbPath, Hop};
use rust_decimal::Decimal;
use tracing::debug;

use crate::pool_registry::PoolRegistry;

const WETH_USD_PRICE: f64 = 3200.0;
const WEI_PER_ETH: f64 = 1e18;

pub struct PathSimulator;

impl PathSimulator {
    pub fn new() -> Self {
        Self
    }

    /// Re-simulate a candidate ArbPath using fresh registry state.
    /// Returns updated ArbPath with accurate profit and gas estimates.
    pub async fn simulate(&self, path: &ArbPath, registry: &PoolRegistry) -> Result<ArbPath> {
        let mut current_amount = path.input_amount;
        let mut simulated_hops: Vec<Hop> = Vec::new();

        for hop in &path.hops {
            let pool = match registry.get(&hop.pool) {
                Some(p) => p,
                None => {
                    debug!("Pool {} not in registry, skipping path", hop.pool);
                    return Ok(path.clone()); // Return original if pool missing
                }
            };

            // Determine which direction we're swapping
            let (reserve_in, reserve_out) = if hop.token_in.address == pool.token0.address {
                (pool.reserve0, pool.reserve1)
            } else {
                (pool.reserve1, pool.reserve0)
            };

            let amount_out = get_amount_out_v2(current_amount, reserve_in, reserve_out, pool.fee_bps);

            if amount_out.is_zero() {
                // Path broken — insufficient liquidity
                return Ok(ArbPath {
                    expected_profit_wei: -1, // Mark as unprofitable
                    ..path.clone()
                });
            }

            let amount_out_min = amount_out * 995u64 / 1000u64; // 0.5% slippage

            simulated_hops.push(Hop {
                pool: hop.pool,
                dex: hop.dex.clone(),
                token_in: hop.token_in.clone(),
                token_out: hop.token_out.clone(),
                amount_in: current_amount,
                amount_out_min,
            });

            current_amount = amount_out;
        }

        let input_i128 = path.input_amount.min(U256::from(u128::MAX)).as_u128() as i128;
        let output_i128 = current_amount.min(U256::from(u128::MAX)).as_u128() as i128;
        let profit_wei = output_i128 - input_i128;

        let profit_eth = profit_wei as f64 / WEI_PER_ETH;
        let profit_usd = Decimal::from_f64_retain(profit_eth * WETH_USD_PRICE)
            .unwrap_or(Decimal::ZERO);

        // Gas: base 150k + 80k per hop + 50k flash loan overhead
        let gas_estimate = 150_000 + (simulated_hops.len() as u64 * 80_000) + 50_000;

        // Confidence decays with more hops (more stale state risk)
        let confidence = (0.95_f64).powi(simulated_hops.len() as i32);

        Ok(ArbPath {
            id: path.id,
            hops: simulated_hops,
            input_token: path.input_token.clone(),
            input_amount: path.input_amount,
            expected_output: current_amount,
            expected_profit_wei: profit_wei,
            expected_profit_usd: profit_usd,
            gas_estimate,
            confidence,
            detected_at: Utc::now(),
        })
    }
}

/// Uniswap V2 constant-product output with fee
fn get_amount_out_v2(amount_in: U256, reserve_in: U256, reserve_out: U256, fee_bps: u32) -> U256 {
    if reserve_in.is_zero() || reserve_out.is_zero() || amount_in.is_zero() {
        return U256::zero();
    }
    let fee_num = U256::from(10000u64 - fee_bps as u64);
    let amount_in_with_fee = amount_in * fee_num;
    let numerator = amount_in_with_fee * reserve_out;
    let denominator = reserve_in * U256::from(10000u64) + amount_in_with_fee;
    numerator / denominator
}

// Trait for f64 -> Decimal (not in std)
trait FromF64Retain {
    fn from_f64_retain(val: f64) -> Option<Self> where Self: Sized;
}

impl FromF64Retain for Decimal {
    fn from_f64_retain(val: f64) -> Option<Self> {
        use std::str::FromStr;
        Decimal::from_str(&format!("{:.8}", val)).ok()
    }
}
