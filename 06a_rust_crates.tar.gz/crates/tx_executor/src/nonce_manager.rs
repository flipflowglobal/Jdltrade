// crates/tx_executor/src/nonce_manager.rs
//! Thread-safe nonce manager to prevent duplicate nonces under parallel execution

use ethers::types::U256;

pub struct NonceManager {
    current: U256,
}

impl NonceManager {
    pub fn new(starting_nonce: U256) -> Self {
        Self { current: starting_nonce }
    }

    pub fn next(&mut self) -> U256 {
        let n = self.current;
        self.current += U256::one();
        n
    }

    pub fn reset(&mut self, nonce: U256) {
        self.current = nonce;
    }
}

// crates/tx_executor/src/gas_oracle.rs
