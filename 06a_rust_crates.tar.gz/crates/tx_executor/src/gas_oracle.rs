// crates/tx_executor/src/gas_oracle.rs
use anyhow::Result;
use ethers::{
    providers::{Http, Middleware, Provider},
    types::U256,
};
use jdl_core::metrics::CURRENT_GAS_GWEI;
use tracing::debug;

pub struct GasOracle {
    pub max_gas_gwei: u64,
}

impl GasOracle {
    pub fn new(max_gas_gwei: u64) -> Self {
        Self { max_gas_gwei }
    }

    /// Get current base fee + priority fee suggestion in gwei
    pub async fn get_gas_price(&self, provider: &Provider<Http>) -> Result<u64> {
        let fee_history = provider
            .fee_history(5u64, ethers::types::BlockNumber::Latest, &[50.0])
            .await?;

        let base_fee = fee_history
            .base_fee_per_gas
            .last()
            .copied()
            .unwrap_or_default();

        // 50th percentile priority fee from last 5 blocks
        let priority_fee = fee_history
            .reward
            .iter()
            .filter_map(|r| r.first().copied())
            .last()
            .unwrap_or(U256::from(100_000_000u64)); // 0.1 gwei default

        let total_gwei = (base_fee + priority_fee).as_u64() / 1_000_000_000;
        CURRENT_GAS_GWEI.set(total_gwei as f64);

        debug!("Gas price: {} gwei (base: {}, priority: {})",
            total_gwei,
            base_fee.as_u64() / 1_000_000_000,
            priority_fee.as_u64() / 1_000_000_000
        );

        Ok(total_gwei)
    }

    /// Compute congestion score 0.0 (low) - 1.0 (high)
    pub fn congestion_score(&self, current_gwei: u64) -> f64 {
        (current_gwei as f64 / self.max_gas_gwei as f64).min(1.0)
    }

    pub fn is_acceptable(&self, gas_gwei: u64) -> bool {
        gas_gwei <= self.max_gas_gwei
    }
}

// crates/tx_executor/src/bundle_builder.rs
