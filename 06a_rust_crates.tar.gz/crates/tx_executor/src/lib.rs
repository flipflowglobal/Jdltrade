// crates/tx_executor/src/lib.rs
//! Handles signing, gas estimation, submission, and receipt confirmation.
//! Implements nonce management, retry logic, and circuit breaker.

pub mod nonce_manager;
pub mod gas_oracle;
pub mod bundle_builder;

pub use nonce_manager::NonceManager;
pub use gas_oracle::GasOracle;

use std::sync::Arc;
use std::time::{Duration, Instant};

use anyhow::{anyhow, Result};
use chrono::Utc;
use ethers::{
    middleware::SignerMiddleware,
    providers::{Http, Middleware, Provider},
    signers::{LocalWallet, Signer},
    types::{
        transaction::eip2718::TypedTransaction, Address, Bytes, TransactionRequest, U256, H256,
    },
};
use jdl_core::{
    config::JdlConfig,
    metrics::{ARB_EXECUTIONS_ATTEMPTED, ARB_EXECUTIONS_SUCCESS, EXECUTION_LATENCY_MS, TOTAL_PROFIT_WEI},
    types::{ArbPath, ExecutionResult, FlashLoanParams, FlashLoanProvider},
    JdlError,
};
use tokio::sync::Mutex;
use tracing::{error, info, warn};

type SignedProvider = SignerMiddleware<Provider<Http>, LocalWallet>;

pub struct TxExecutor {
    provider: Arc<SignedProvider>,
    config: JdlConfig,
    nonce_manager: Arc<Mutex<NonceManager>>,
    gas_oracle: Arc<GasOracle>,
    daily_loss_wei: Arc<Mutex<i128>>,
    circuit_open: Arc<Mutex<bool>>,
}

impl TxExecutor {
    pub async fn new(config: JdlConfig) -> Result<Self> {
        // Load private key from env — NEVER from config file
        let pk = std::env::var(&config.execution.private_key_env)
            .map_err(|_| anyhow!("Private key env var {} not set", config.execution.private_key_env))?;

        let wallet: LocalWallet = pk.parse::<LocalWallet>()?
            .with_chain_id(config.network.chain_id);

        let provider = Provider::<Http>::try_from(&config.network.rpc_http_url)?;
        let signed = SignerMiddleware::new(provider.clone(), wallet);
        let signed = Arc::new(signed);

        let nonce = signed.get_transaction_count(signed.address(), None).await?;
        let nonce_manager = Arc::new(Mutex::new(NonceManager::new(nonce)));
        let gas_oracle = Arc::new(GasOracle::new(config.risk.max_gas_gwei));

        Ok(Self {
            provider: signed,
            config,
            nonce_manager,
            gas_oracle,
            daily_loss_wei: Arc::new(Mutex::new(0)),
            circuit_open: Arc::new(Mutex::new(false)),
        })
    }

    /// Execute a validated arbitrage path via flash loan receiver contract
    pub async fn execute_arb(&self, path: &ArbPath, gas_price_gwei: u64) -> ExecutionResult {
        ARB_EXECUTIONS_ATTEMPTED.inc();
        let start = Instant::now();

        // Circuit breaker check
        if *self.circuit_open.lock().await {
            return ExecutionResult {
                tx_hash: None,
                success: false,
                profit_wei: 0,
                gas_used: 0,
                error: Some("Circuit breaker open".to_string()),
                executed_at: Utc::now(),
            };
        }

        // Dry run guard
        if self.config.execution.dry_run {
            info!(
                "DRY RUN: Would execute arb path {} hops, expected profit {} wei",
                path.hops.len(),
                path.expected_profit_wei
            );
            return ExecutionResult {
                tx_hash: None,
                success: true,
                profit_wei: path.expected_profit_wei,
                gas_used: path.gas_estimate,
                error: None,
                executed_at: Utc::now(),
            };
        }

        // Gas price check
        if gas_price_gwei > self.config.risk.max_gas_gwei {
            return ExecutionResult {
                tx_hash: None,
                success: false,
                profit_wei: 0,
                gas_used: 0,
                error: Some(format!("Gas price {} > max {}", gas_price_gwei, self.config.risk.max_gas_gwei)),
                executed_at: Utc::now(),
            };
        }

        match self.submit_flash_arb(path, gas_price_gwei).await {
            Ok((tx_hash, profit, gas_used)) => {
                let elapsed = start.elapsed().as_millis() as f64;
                EXECUTION_LATENCY_MS.observe(elapsed);
                ARB_EXECUTIONS_SUCCESS.inc();
                TOTAL_PROFIT_WEI.add(profit as f64);

                info!(
                    "Arb executed: tx={:?}, profit={} wei, gas={}, latency={}ms",
                    tx_hash, profit, gas_used, elapsed
                );

                ExecutionResult {
                    tx_hash: Some(tx_hash),
                    success: true,
                    profit_wei: profit,
                    gas_used,
                    error: None,
                    executed_at: Utc::now(),
                }
            }
            Err(e) => {
                error!("Arb execution failed: {}", e);

                // Update daily loss tracking
                let gas_cost = path.gas_estimate as i128 * gas_price_gwei as i128 * 1_000_000_000;
                self.update_loss_tracker(gas_cost).await;

                ExecutionResult {
                    tx_hash: None,
                    success: false,
                    profit_wei: -gas_cost,
                    gas_used: path.gas_estimate,
                    error: Some(e.to_string()),
                    executed_at: Utc::now(),
                }
            }
        }
    }

    async fn submit_flash_arb(
        &self,
        path: &ArbPath,
        gas_price_gwei: u64,
    ) -> Result<(H256, i128, u64)> {
        // Encode flash loan + arb payload for receiver contract
        let calldata = self.encode_arb_calldata(path)?;

        let mut nonce_guard = self.nonce_manager.lock().await;
        let nonce = nonce_guard.next();

        let gas_price_wei = U256::from(gas_price_gwei) * U256::from(1_000_000_000u64);
        let deadline = U256::from(
            (Utc::now().timestamp() + self.config.execution.deadline_secs as i64) as u64
        );

        let tx = TransactionRequest::new()
            .to(self.config.flash_loan.receiver_contract)
            .data(calldata)
            .gas(path.gas_estimate + 50_000) // buffer
            .gas_price(gas_price_wei)
            .nonce(nonce)
            .chain_id(self.config.network.chain_id);

        let typed: TypedTransaction = tx.into();

        // Submit with retry
        let pending_tx = self.provider
            .send_transaction(typed, None)
            .await
            .map_err(|e| anyhow!("Tx submission failed: {}", e))?;

        let tx_hash = pending_tx.tx_hash();
        info!("Tx submitted: {:?}", tx_hash);

        // Wait for receipt with timeout
        let receipt = tokio::time::timeout(
            Duration::from_secs(60),
            pending_tx.await,
        )
        .await
        .map_err(|_| anyhow!("Tx confirmation timeout"))?
        .map_err(|e| anyhow!("Receipt error: {}", e))?
        .ok_or_else(|| anyhow!("No receipt returned"))?;

        if receipt.status == Some(1u64.into()) {
            let gas_used = receipt.gas_used.unwrap_or_default().as_u64();
            // In production: decode logs to get actual profit
            let profit = path.expected_profit_wei;
            Ok((tx_hash, profit, gas_used))
        } else {
            Err(anyhow!("Transaction reverted: {:?}", receipt.transaction_hash))
        }
    }

    fn encode_arb_calldata(&self, path: &ArbPath) -> Result<Bytes> {
        // Encode: executeArb(hops[], flashToken, flashAmount)
        // In production this uses ethers ABI encoding against your receiver ABI
        // Placeholder: encode as JSON bytes for now (replace with ABI encoder)
        let payload = serde_json::json!({
            "hops": path.hops.len(),
            "input_amount": path.input_amount.to_string(),
            "min_profit": path.expected_profit_wei.to_string(),
        });
        Ok(Bytes::from(serde_json::to_vec(&payload)?))
    }

    async fn update_loss_tracker(&self, loss_wei: i128) {
        let mut daily_loss = self.daily_loss_wei.lock().await;
        *daily_loss += loss_wei;

        let max_loss_eth = self.config.risk.max_daily_loss_usd.to_string()
            .parse::<f64>().unwrap_or(1000.0) / 3200.0;
        let max_loss_wei = (max_loss_eth * 1e18) as i128;

        if *daily_loss >= max_loss_wei {
            let mut cb = self.circuit_open.lock().await;
            *cb = true;
            error!("CIRCUIT BREAKER OPENED: daily loss {} wei exceeds limit", *daily_loss);
            jdl_core::metrics::CIRCUIT_BREAKER_STATE.set(1.0);
        }
    }

    pub async fn reset_daily_loss(&self) {
        *self.daily_loss_wei.lock().await = 0;
        *self.circuit_open.lock().await = false;
        jdl_core::metrics::CIRCUIT_BREAKER_STATE.set(0.0);
        info!("Daily loss counter reset, circuit breaker closed");
    }

    pub fn address(&self) -> Address {
        self.provider.address()
    }
}
