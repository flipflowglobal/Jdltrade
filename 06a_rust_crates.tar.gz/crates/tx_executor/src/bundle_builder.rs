// crates/tx_executor/src/bundle_builder.rs
//! Flashbots bundle builder for MEV-protected submission.
//! Prevents sandwich attacks on JDL's own arbitrage transactions.

use anyhow::Result;
use chrono::Utc;
use ethers::{
    types::{Bytes, H256, U256, U64},
};
use reqwest::Client;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};
use tracing::{debug, info, warn};

const FLASHBOTS_RELAY_ARBITRUM: &str = "https://relay.flashbots.net"; // Use chain-specific
const BLOXROUTE_ENDPOINT: &str = "https://mev.api.blxrbdn.com";

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BundleTx {
    pub signed_tx: Bytes,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FlashbotsBundle {
    pub txs: Vec<BundleTx>,
    pub block_number: U64,
    pub min_timestamp: Option<u64>,
    pub max_timestamp: Option<u64>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BundleSimResult {
    pub bundle_hash: H256,
    pub coinbase_diff: U256,
    pub eth_sent_to_coinbase: U256,
    pub gas_fees: U256,
    pub results: Vec<TxSimResult>,
    pub total_gas_used: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TxSimResult {
    pub tx_hash: H256,
    pub gas_used: u64,
    pub revert: Option<String>,
    pub value: U256,
}

pub struct BundleBuilder {
    client: Client,
    relay_url: String,
    use_private_relay: bool,
}

impl BundleBuilder {
    pub fn new(use_private_relay: bool) -> Self {
        Self {
            client: Client::new(),
            relay_url: FLASHBOTS_RELAY_ARBITRUM.to_string(),
            use_private_relay,
        }
    }

    /// Simulate a bundle before submission
    pub async fn simulate(
        &self,
        bundle: &FlashbotsBundle,
        state_block: u64,
    ) -> Result<BundleSimResult> {
        let payload = json!({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "eth_callBundle",
            "params": [{
                "txs": bundle.txs.iter().map(|t| format!("0x{}", hex::encode(&t.signed_tx))).collect::<Vec<_>>(),
                "blockNumber": format!("0x{:x}", bundle.block_number),
                "stateBlockNumber": format!("0x{:x}", state_block),
                "timestamp": Utc::now().timestamp() as u64,
            }]
        });

        let resp = self.client
            .post(&self.relay_url)
            .json(&payload)
            .send()
            .await?
            .json::<Value>()
            .await?;

        debug!("Bundle simulation response: {:?}", resp);

        if let Some(error) = resp.get("error") {
            return Err(anyhow::anyhow!("Bundle simulation error: {:?}", error));
        }

        let result = resp["result"].clone();
        let sim = BundleSimResult {
            bundle_hash: result["bundleHash"].as_str()
                .and_then(|s| s.parse().ok())
                .unwrap_or_default(),
            coinbase_diff: result["coinbaseDiff"].as_str()
                .and_then(|s| U256::from_dec_str(s).ok())
                .unwrap_or_default(),
            eth_sent_to_coinbase: result["ethSentToCoinbase"].as_str()
                .and_then(|s| U256::from_dec_str(s).ok())
                .unwrap_or_default(),
            gas_fees: result["gasFees"].as_str()
                .and_then(|s| U256::from_dec_str(s).ok())
                .unwrap_or_default(),
            total_gas_used: result["totalGasUsed"].as_u64().unwrap_or_default(),
            results: vec![],
        };

        info!(
            "Bundle sim: coinbase_diff={} gas={}",
            sim.coinbase_diff,
            sim.total_gas_used
        );

        Ok(sim)
    }

    /// Submit bundle to Flashbots relay
    pub async fn send_bundle(
        &self,
        bundle: &FlashbotsBundle,
    ) -> Result<H256> {
        if !self.use_private_relay {
            warn!("Private relay disabled — tx will be public mempool (sandwich risk!)");
            return Err(anyhow::anyhow!("Private relay not configured"));
        }

        let payload = json!({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "eth_sendBundle",
            "params": [{
                "txs": bundle.txs.iter().map(|t| format!("0x{}", hex::encode(&t.signed_tx))).collect::<Vec<_>>(),
                "blockNumber": format!("0x{:x}", bundle.block_number),
                "minTimestamp": bundle.min_timestamp,
                "maxTimestamp": bundle.max_timestamp,
            }]
        });

        let resp = self.client
            .post(&self.relay_url)
            .json(&payload)
            .send()
            .await?
            .json::<Value>()
            .await?;

        if let Some(error) = resp.get("error") {
            return Err(anyhow::anyhow!("Bundle submission error: {:?}", error));
        }

        let bundle_hash = resp["result"]["bundleHash"]
            .as_str()
            .and_then(|s| s.parse().ok())
            .unwrap_or_default();

        info!("Bundle submitted: {:?}", bundle_hash);
        Ok(bundle_hash)
    }
}
