# JDL Rust Enhancement Layer

Rust-accelerated hot paths for the JDL DeFi arbitrage system.
Wraps the Python core with a compiled execution engine via PyO3.

## Architecture

```
┌───────────────────────────────────────────────────────────┐
│                    PYTHON JDL CORE                         │
│  FastAPI │ PPO Agent │ UKF │ Thompson Sampling │ SQLite   │
│                  jdl_rust_bridge.py                        │
└──────────────────────┬────────────────────────────────────┘
                  PyO3 FFI (zero-copy)
┌──────────────────────▼────────────────────────────────────┐
│                  RUST ENGINE (jdl_rust.so)                 │
│                                                            │
│  mempool_scanner  →  path_finder  →  risk_engine          │
│  (WebSocket/async)   (Bellman-Ford)  (Oracle/CB/Regime)   │
│                         ↓                                  │
│                    tx_executor                             │
│               (ethers-rs, nonce mgmt)                     │
└───────────────────────────────────────────────────────────┘
```

## Performance Gains

| Operation             | Python    | Rust      | Speedup |
|-----------------------|-----------|-----------|---------|
| Bellman-Ford (50 pools)| ~45ms    | ~0.8ms    | 56x     |
| Pool reserve update   | ~2ms      | ~0.02ms   | 100x    |
| Mempool decode        | ~8ms/tx   | ~0.15ms   | 53x     |
| Oracle health check   | ~5ms      | ~0.05ms   | 100x    |

## Quick Start (UserLAnd ARM)

```bash
# Clone or extract into your JDL project directory
cd ~/jdl_rust

# Build (first time takes ~5-10 min on ARM)
chmod +x build.sh && ./build.sh dev

# Test
python3 -c "
from jdl_rust_bridge import get_bridge
import json

bridge = get_bridge()
bridge.init({
    'network': {'rpc_ws_url': 'wss://...', 'rpc_http_url': 'https://...'},
    'execution': {'min_profit_wei': 100000000000000, 'max_hops': 3}
})
print('Rust available:', bridge.is_available)
print('Pool count:', bridge.pool_count())
"
```

## Integration into Existing JDL

### 1. Pool Registry (replace Python pool cache)
```python
from jdl_rust_bridge import get_bridge
bridge = get_bridge()
bridge.init(config)

# On every Sync event (replaces Python dict update):
bridge.update_reserves(pool_address, reserve0, reserve1)

# On new pool discovery:
bridge.update_pool({
    "address": "0x...",
    "dex": "UniswapV2",
    "token0": {"address": "0x...", "symbol": "WETH", "decimals": 18},
    "token1": {"address": "0x...", "symbol": "USDC", "decimals": 6},
    "reserve0": "1000000000000000000",
    "reserve1": "3200000000",
    "fee_bps": 30
})
```

### 2. Path Finding (replaces Python Bellman-Ford)
```python
# Instead of your existing find_arbitrage_paths():
paths = bridge.find_arb_paths(
    token_in_address=WETH_ADDRESS,
    amount_wei=int(0.1 * 1e18),   # 0.1 ETH
    gas_price_gwei=current_gas_gwei
)

for path in paths:
    if path.is_profitable(current_gas_gwei, min_profit_wei=50_000_000_000_000):
        print(f"Profit: {path.expected_profit_wei} wei, Hops: {len(path.hops)}")
        # Pass to flash loan executor
        execute_arb(path)
```

### 3. Risk Gating
```python
# Before any execution:
risk = bridge.get_risk_signal()
if risk["circuit_breaker_open"]:
    return  # Skip

if not bridge.check_oracle_health(dex_price, chainlink_price):
    logger.warning("Oracle manipulation — skipping")
    return

congestion = bridge.update_gas_price(gas_gwei)
if congestion > 0.8:
    logger.info("Network congested — skipping")
    return
```

## Crate Structure

```
crates/
├── jdl_core/          # Shared types, config, metrics, errors
├── mempool_scanner/   # Async WebSocket mempool scanner + MEV detector
├── path_finder/       # Bellman-Ford DEX graph + path simulator
├── tx_executor/       # ethers-rs tx signing, nonce mgmt, circuit breaker
├── risk_engine/       # Oracle health, regime detection, position sizing
└── pyo3_bridge/       # Python extension module (jdl_rust.so)
```

## Environment Variables

```bash
export JDL_PRIVATE_KEY="0x..."          # Wallet private key (NEVER in config)
export RPC_WS_URL="wss://..."           # Arbitrum WebSocket RPC
export RPC_HTTP_URL="https://..."       # Arbitrum HTTP RPC
export FLASH_RECEIVER_ADDRESS="0x..."  # Deployed flash loan receiver
export JDL_CONFIG_PATH="config/jdl_config.json"
export ALERT_WEBHOOK_URL="https://..."  # Optional Slack/Discord webhook
```

## Attack Surface Analysis

| Threat                    | Severity | Mitigation                              |
|---------------------------|----------|-----------------------------------------|
| Private key exposure      | Critical | Env var only, never in config/logs      |
| Oracle manipulation       | High     | Chainlink cross-check, 5% deviation cap |
| Sandwich MEV on own txs   | High     | Private mempool / Flashbots recommended |
| Stale reserve data        | High     | Staleness check + re-sim before submit  |
| Nonce collision           | Medium   | Mutex-guarded NonceManager              |
| Circuit breaker bypass    | Medium   | Atomic RwLock, no override in hot path  |
| Gas spike losses          | Medium   | Hard max_gas_gwei cap                   |
| Integer overflow (U256)   | Low      | Rust prevents; explicit bounds on casts |

## Scaling Roadmap

- **10x pools**: Graph rebuild O(n) is fine; parallel edge relaxation via rayon
- **100x tx volume**: Add Tokio task semaphore to cap concurrent submissions
- **1000x**: Shard pool registry by token pair; distributed path finding via message queue
