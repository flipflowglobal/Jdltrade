#!/usr/bin/env bash
# ================================================================
# JDL Rust Enhancement Layer — Build Script
# Targets: UserLAnd Ubuntu ARM/aarch64 (Android)
# ================================================================
set -euo pipefail

echo "🦀 JDL Rust Enhancement Layer — Build Script"
echo "============================================="

# ── 1. Rust Toolchain ─────────────────────────────────────────
if ! command -v rustup &>/dev/null; then
    echo "📦 Installing Rust..."
    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y --default-toolchain stable
    source "$HOME/.cargo/env"
else
    echo "✅ Rust $(rustc --version) found"
fi

# Ensure stable toolchain active
rustup default stable
rustup target add aarch64-unknown-linux-gnu 2>/dev/null || true

# ── 2. System Dependencies ────────────────────────────────────
echo "📦 Installing system deps..."
sudo apt-get update -qq
sudo apt-get install -y -qq \
    build-essential \
    pkg-config \
    libssl-dev \
    libclang-dev \
    python3-dev \
    python3-pip \
    clang

# ── 3. Python Build Tools ─────────────────────────────────────
echo "🐍 Installing maturin..."
pip install maturin --break-system-packages 2>/dev/null || pip install maturin

# ── 4. Compile Rust Library (debug for dev, release for prod) ─
MODE="${1:-dev}"
echo "🔨 Building in $MODE mode..."

if [ "$MODE" = "release" ]; then
    maturin develop --release
else
    maturin develop
fi

echo ""
echo "✅ Build complete!"
echo ""
echo "📋 Verify the build:"
echo "   python3 -c \"import jdl_rust; e = jdl_rust.RustArbEngine('wss://test', 'https://test'); print('Engine pools:', e.pool_count())\""
echo ""
echo "🔌 Integrate with JDL:"
echo "   from jdl_rust_bridge import get_bridge"
echo "   bridge = get_bridge()"
echo "   bridge.init(config)"
echo ""
echo "📊 Metrics endpoint: http://localhost:9090/metrics (once running)"
