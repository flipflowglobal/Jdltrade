# jdl_rust_bridge.py
"""
Drop-in integration shim for JDL Python system.
Replaces slow Python path-finding and risk checks with compiled Rust.

Usage in existing JDL code:
    from jdl_rust_bridge import RustBridge
    bridge = RustBridge()
    bridge.init(config)
    paths = bridge.find_arb_paths(token_addr, amount_wei, gas_gwei)
"""

import json
import os
import logging
from typing import Optional, List, Dict, Any
from dataclasses import dataclass

logger = logging.getLogger(__name__)

# Try to import compiled Rust extension
try:
    import jdl_rust
    RUST_AVAILABLE = True
    logger.info("✅ Rust arbitrage engine loaded successfully")
except ImportError:
    RUST_AVAILABLE = False
    logger.warning("⚠️  Rust engine not available — falling back to Python implementation")


@dataclass
class ArbPathResult:
    """Parsed arbitrage path from Rust engine"""
    id: str
    hops: List[Dict]
    input_token: Dict
    input_amount: int
    expected_output: int
    expected_profit_wei: int
    expected_profit_usd: float
    gas_estimate: int
    confidence: float

    def net_profit_after_gas(self, gas_price_gwei: int) -> int:
        gas_cost = self.gas_estimate * gas_price_gwei * 1_000_000_000
        return self.expected_profit_wei - gas_cost

    def is_profitable(self, gas_price_gwei: int, min_profit_wei: int = 0) -> bool:
        return self.net_profit_after_gas(gas_price_gwei) >= min_profit_wei


class RustBridge:
    """
    Wraps the Rust ArbEngine with Python-friendly interface.
    Falls back to stub if Rust binary not compiled yet.
    """

    def __init__(self):
        self._engine = None
        self._available = RUST_AVAILABLE

    def init(self, config: Dict[str, Any]) -> bool:
        """Initialize Rust engine from JDL config dict"""
        if not self._available:
            logger.warning("Rust engine not compiled — run: maturin develop --release")
            return False

        try:
            rpc_ws = config.get("network", {}).get("rpc_ws_url", os.getenv("RPC_WS_URL", ""))
            rpc_http = config.get("network", {}).get("rpc_http_url", os.getenv("RPC_HTTP_URL", ""))
            min_profit = config.get("execution", {}).get("min_profit_wei", 100_000_000_000_000)
            max_hops = config.get("execution", {}).get("max_hops", 3)

            self._engine = jdl_rust.RustArbEngine(
                rpc_ws,
                rpc_http,
                min_profit_wei=min_profit,
                max_hops=max_hops
            )
            logger.info(f"Rust engine initialized — max_hops={max_hops}, min_profit={min_profit} wei")
            return True
        except Exception as e:
            logger.error(f"Failed to initialize Rust engine: {e}")
            self._available = False
            return False

    def update_pool(self, pool_data: Dict) -> bool:
        """Register or update a pool. Call on every Sync event."""
        if not self._engine:
            return False
        try:
            self._engine.update_pool(json.dumps(pool_data))
            return True
        except Exception as e:
            logger.error(f"update_pool error: {e}")
            return False

    def update_reserves(self, pool_address: str, reserve0: int, reserve1: int) -> bool:
        """Fast-path reserve update without full pool re-registration."""
        if not self._engine:
            return False
        try:
            self._engine.update_reserves(pool_address, str(reserve0), str(reserve1))
            return True
        except Exception as e:
            logger.error(f"update_reserves error: {e}")
            return False

    def find_arb_paths(
        self,
        token_in_address: str,
        amount_wei: int,
        gas_price_gwei: int
    ) -> List[ArbPathResult]:
        """
        Find profitable arbitrage paths.
        Returns sorted list (most profitable first).
        """
        if not self._engine:
            return []

        try:
            raw_json = self._engine.find_arb_paths(
                token_in_address,
                str(amount_wei),
                gas_price_gwei
            )
            paths_data = json.loads(raw_json)
            return [self._parse_path(p) for p in paths_data]
        except Exception as e:
            logger.error(f"find_arb_paths error: {e}")
            return []

    def update_gas_price(self, gas_gwei: int) -> float:
        """Update gas oracle, returns congestion score 0.0-1.0"""
        if not self._engine:
            return 0.0
        try:
            return self._engine.update_gas_price(gas_gwei)
        except Exception as e:
            logger.error(f"update_gas_price error: {e}")
            return 0.0

    def check_oracle_health(
        self,
        dex_price: float,
        chainlink_price: Optional[float] = None
    ) -> bool:
        """Returns False if oracle manipulation detected"""
        if not self._engine:
            return True
        try:
            return self._engine.update_price(dex_price, chainlink_price)
        except Exception as e:
            logger.error(f"oracle check error: {e}")
            return True

    def get_risk_signal(self) -> Dict:
        """Get current risk assessment as dict"""
        if not self._engine:
            return {"circuit_breaker_open": False, "oracle_health": 1.0}
        try:
            return json.loads(self._engine.get_risk_signal())
        except Exception as e:
            logger.error(f"get_risk_signal error: {e}")
            return {}

    def open_circuit_breaker(self):
        if self._engine:
            self._engine.open_circuit_breaker()

    def close_circuit_breaker(self):
        if self._engine:
            self._engine.close_circuit_breaker()

    def pool_count(self) -> int:
        if not self._engine:
            return 0
        return self._engine.pool_count()

    def _parse_path(self, data: Dict) -> ArbPathResult:
        return ArbPathResult(
            id=data.get("id", ""),
            hops=data.get("hops", []),
            input_token=data.get("input_token", {}),
            input_amount=int(data.get("input_amount", 0)),
            expected_output=int(data.get("expected_output", 0)),
            expected_profit_wei=int(data.get("expected_profit_wei", 0)),
            expected_profit_usd=float(str(data.get("expected_profit_usd", "0"))),
            gas_estimate=int(data.get("gas_estimate", 0)),
            confidence=float(data.get("confidence", 0.0)),
        )

    @property
    def is_available(self) -> bool:
        return self._available and self._engine is not None


# Singleton instance for use across JDL modules
_bridge_instance: Optional[RustBridge] = None

def get_bridge() -> RustBridge:
    global _bridge_instance
    if _bridge_instance is None:
        _bridge_instance = RustBridge()
    return _bridge_instance
